import React, { useState, useMemo } from 'react';
import { useIDP } from '../context/IDPContext';
import { GoldenPathTemplate, ProvisioningJob, CloudProvider } from '../types/idp';
import {
  X,
  Workflow,
  CheckCircle2,
  ShieldCheck,
  FileCode,
  ArrowRight,
  ArrowLeft,
  Terminal,
  Server,
  Layers,
  DollarSign,
  AlertCircle,
  ExternalLink,
  RefreshCw,
} from 'lucide-react';

export const ProvisioningWizardModal: React.FC = () => {
  const {
    isProvisionModalOpen,
    setIsProvisionModalOpen,
    templates,
    startProvisioning,
    activeProvisionJob,
    setActiveProvisionJob,
    setSelectedService,
    services,
  } = useIDP();

  const [currentStep, setCurrentStep] = useState<number>(1);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>(templates[0]?.id || '');
  const [serviceName, setServiceName] = useState<string>('payment-orchestrator');
  const [displayName, setDisplayName] = useState<string>('Payment Orchestrator');
  const [ownerTeam, setOwnerTeam] = useState<string>('FinPlatform');
  const [environment, setEnvironment] = useState<'production' | 'staging' | 'development'>('production');
  const [cloudProvider, setCloudProvider] = useState<CloudProvider>('aws');
  const [region, setRegion] = useState<string>('us-east-1');
  const [sizingPreset, setSizingPreset] = useState<'lightweight' | 'standard' | 'high_throughput'>('standard');
  const [enableDatabase, setEnableDatabase] = useState<boolean>(true);
  const [activeCodeTab, setActiveCodeTab] = useState<'terraform' | 'kubernetes' | 'cicd'>('terraform');

  const selectedTemplate = useMemo(() => {
    return templates.find((t) => t.id === selectedTemplateId) || templates[0];
  }, [templates, selectedTemplateId]);

  // Compute live estimated cost
  const calculatedCost = useMemo(() => {
    let base = selectedTemplate?.estimatedMonthlyCost || 85;
    if (sizingPreset === 'lightweight') base = 45;
    if (sizingPreset === 'high_throughput') base = 190;
    if (enableDatabase) base += 210;
    if (environment === 'staging') base = Math.round(base * 0.6);
    return base;
  }, [selectedTemplate, sizingPreset, enableDatabase, environment]);

  // Dynamic Terraform generation based on user input
  const generatedTerraform = useMemo(() => {
    return `# Dynamic Terraform Configuration synthesized by Nexus IDP
terraform {
  required_version = ">= 1.7.0"
  required_providers {
    ${cloudProvider} = {
      source  = "hashicorp/${cloudProvider}"
      version = "~> 5.40"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.26"
    }
  }
  backend "s3" {
    bucket = "nexus-tfstate-${environment}"
    key    = "services/${serviceName}/terraform.tfstate"
    region = "${region}"
  }
}

module "${serviceName}_workload" {
  source = "git::https://github.com/enterprise/terraform-modules.git//service-workload?ref=v3.2.0"

  service_name        = "${serviceName}"
  environment         = "${environment}"
  owner_team          = "${ownerTeam}"
  cloud_region        = "${region}"
  sizing_preset       = "${sizingPreset}"
  provision_database  = ${enableDatabase}

  datadog_apm_enabled = true
  enable_vault_token  = true

  tags = {
    OwnerTeam   = "${ownerTeam}"
    CostCenter  = "CoreEngineering"
    ManagedBy   = "Nexus-IDP"
    Environment = "${environment}"
  }
}`;
  }, [serviceName, environment, ownerTeam, cloudProvider, region, sizingPreset, enableDatabase]);

  // Dynamic K8s manifest
  const generatedK8s = useMemo(() => {
    return `apiVersion: apps/v1
kind: Deployment
metadata:
  name: ${serviceName}
  namespace: ${environment}-${serviceName}
  labels:
    app.kubernetes.io/name: ${serviceName}
    app.kubernetes.io/part-of: nexus-platform
spec:
  replicas: ${environment === 'production' ? 3 : 1}
  selector:
    matchLabels:
      app: ${serviceName}
  template:
    metadata:
      labels:
        app: ${serviceName}
      annotations:
        ad.datadoghq.com/${serviceName}.logs: '[{"source":"go","service":"${serviceName}"}]'
    spec:
      serviceAccountName: ${serviceName}-sa
      containers:
      - name: app
        image: ecr.nexus.net/${serviceName}:v1.0.0
        ports:
        - containerPort: 8080
          name: http
        resources:
          requests:
            cpu: ${sizingPreset === 'high_throughput' ? '2000m' : '1000m'}
            memory: ${sizingPreset === 'high_throughput' ? '4096Mi' : '2048Mi'}
          limits:
            cpu: ${sizingPreset === 'high_throughput' ? '4000m' : '2000m'}
            memory: ${sizingPreset === 'high_throughput' ? '8192Mi' : '4096Mi'}`;
  }, [serviceName, environment, sizingPreset]);

  // Dynamic CI/CD pipeline
  const generatedCicd = useMemo(() => {
    return `name: Deploy ${serviceName}
on:
  push:
    branches: [main]

jobs:
  build-and-sync:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Run Trivy Security Vulnerability Scan
        uses: aquasecurity/trivy-action@master
        with:
          scan-type: 'fs'
          severity: 'CRITICAL,HIGH'
      - name: GitOps ArgoCD Trigger
        uses: enterprise/argocd-sync-action@v2
        with:
          app-name: ${serviceName}-${environment}`;
  }, [serviceName, environment]);

  if (!isProvisionModalOpen) return null;

  const handleLaunchProvisioning = () => {
    const job: ProvisioningJob = {
      id: `job-${Date.now()}`,
      templateId: selectedTemplate.id,
      templateTitle: selectedTemplate.title,
      serviceName,
      displayName,
      ownerTeam,
      environment,
      cloudProvider,
      region,
      status: 'in_progress',
      startedAt: new Date().toLocaleTimeString(),
      currentStepIndex: 0,
      steps: [
        { id: 'step-repo', name: 'Scaffold GitOps Repo', description: 'Initialize Git repository with template and CI workflow', status: 'running' },
        { id: 'step-tf', name: 'Apply Terraform Cloud State', description: 'Provision IAM roles, DNS records, and VPC endpoints', status: 'pending' },
        { id: 'step-k8s', name: 'Deploy Kubernetes Workload', description: 'Create namespace, ServiceAccount, and Helm chart', status: 'pending' },
        { id: 'step-argo', name: 'Verify ArgoCD & Health Probes', description: 'Wait for HTTP 200 healthcheck and TLS certificate', status: 'pending' },
      ],
      tfPlanDiff: generatedTerraform,
      infracostDiff: {
        previousCostMonthly: 0,
        newCostMonthly: calculatedCost,
        deltaMonthly: calculatedCost,
        breakdown: [
          { resource: 'EKS Compute Pods (x3)', cost: sizingPreset === 'high_throughput' ? 120 : 65, change: '+new' },
          { resource: enableDatabase ? 'RDS Aurora PostgreSQL' : 'State Cache (Redis)', cost: enableDatabase ? 210 : 20, change: '+new' },
          { resource: 'Ingress & Route53 DNS', cost: 15, change: '+new' },
        ],
      },
      outputs: {},
      logs: [
        { timestamp: new Date().toLocaleTimeString(), level: 'info', message: `[Nexus Engine] Dispatching Golden Path execution for '${serviceName}'...` },
        { timestamp: new Date().toLocaleTimeString(), level: 'info', message: `[Git] Generating project scaffold from template: ${selectedTemplate.title}` },
      ],
    };

    setCurrentStep(5);
    startProvisioning(job);
  };

  const handleFinish = () => {
    setIsProvisionModalOpen(false);
    setCurrentStep(1);
    setActiveProvisionJob(null);
    const created = services.find((s) => s.id === serviceName);
    if (created) {
      setSelectedService(created);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="w-full max-w-4xl bg-slate-950 border border-slate-800 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Wizard Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/80">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600 text-white shadow-sm">
              <Workflow className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Self-Service Infrastructure Provisioner</h2>
              <span className="text-xs text-slate-400 font-mono">
                Backstage Golden Path Wizard · Step {currentStep} of 5
              </span>
            </div>
          </div>
          <button
            onClick={() => setIsProvisionModalOpen(false)}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-md transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Wizard Stepper Bar (Single line, anti-slop) */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-slate-850 bg-slate-900/40 text-xs overflow-x-auto">
          {[
            { num: 1, label: 'Template' },
            { num: 2, label: 'Parameters' },
            { num: 3, label: 'IaC Synthesis' },
            { num: 4, label: 'Security & Cost' },
            { num: 5, label: 'Execution' },
          ].map((st) => (
            <div
              key={st.num}
              className={`flex items-center gap-2 whitespace-nowrap ${
                currentStep === st.num
                  ? 'text-indigo-400 font-semibold'
                  : currentStep > st.num
                  ? 'text-slate-300'
                  : 'text-slate-600'
              }`}
            >
              <span
                className={`flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-mono font-bold ${
                  currentStep === st.num
                    ? 'bg-indigo-600 text-white'
                    : currentStep > st.num
                    ? 'bg-slate-800 text-emerald-400'
                    : 'bg-slate-900 text-slate-600 border border-slate-800'
                }`}
              >
                {currentStep > st.num ? '✓' : st.num}
              </span>
              <span>{st.label}</span>
              {st.num < 5 && <span className="text-slate-800 ml-2 hidden sm:inline">/</span>}
            </div>
          ))}
        </div>

        {/* Wizard Body Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* STEP 1: CHOOSE TEMPLATE */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-semibold text-white">Select a Golden Path Software Template</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Pre-approved platform patterns adhering to enterprise architectural standards.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                {templates.map((tpl) => (
                  <div
                    key={tpl.id}
                    onClick={() => setSelectedTemplateId(tpl.id)}
                    className={`p-4 rounded-lg border cursor-pointer transition-all ${
                      selectedTemplateId === tpl.id
                        ? 'bg-indigo-950/30 border-indigo-500 shadow-md ring-1 ring-indigo-500/50'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <h4 className="text-xs font-bold text-white">{tpl.title}</h4>
                      <span className="font-mono text-[11px] text-emerald-400 font-semibold">
                        ${tpl.estimatedMonthlyCost}/mo
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                      {tpl.description}
                    </p>
                    <div className="mt-3 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                      <span>{tpl.author}</span>
                      <span>{tpl.timeToDeploy}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 2: CONFIGURE PARAMETERS */}
          {currentStep === 2 && (
            <div className="space-y-5">
              <div>
                <h3 className="text-sm font-semibold text-white">Configure Service Parameters</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Template: <span className="text-indigo-400 font-semibold">{selectedTemplate.title}</span>
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300">
                    Service Name (slug)
                  </label>
                  <input
                    type="text"
                    value={serviceName}
                    onChange={(e) => setServiceName(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''))}
                    placeholder="e.g. payment-service"
                    className="mt-1 w-full h-9 px-3 text-xs bg-slate-900 border border-slate-800 rounded-md text-white font-mono focus:outline-none focus:border-indigo-500"
                  />
                  <span className="text-[10px] text-slate-500 mt-0.5 block">
                    DNS and repository slug
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300">
                    Human Readable Display Name
                  </label>
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="e.g. Payment Service"
                    className="mt-1 w-full h-9 px-3 text-xs bg-slate-900 border border-slate-800 rounded-md text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300">
                    Owner Engineering Team
                  </label>
                  <select
                    value={ownerTeam}
                    onChange={(e) => setOwnerTeam(e.target.value)}
                    className="mt-1 w-full h-9 px-3 text-xs bg-slate-900 border border-slate-800 rounded-md text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Checkout Core">Checkout Core</option>
                    <option value="FinPlatform">FinPlatform</option>
                    <option value="SecOps Platform">SecOps Platform</option>
                    <option value="Data Eng">Data Eng</option>
                    <option value="SupplyChain Tech">SupplyChain Tech</option>
                    <option value="Applied ML">Applied ML</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300">
                    Target Environment
                  </label>
                  <select
                    value={environment}
                    onChange={(e) => setEnvironment(e.target.value as any)}
                    className="mt-1 w-full h-9 px-3 text-xs bg-slate-900 border border-slate-800 rounded-md text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="production">Production (Multi-AZ, strict SLO)</option>
                    <option value="staging">Staging (Single-AZ, test traffic)</option>
                    <option value="development">Development (Scale-to-zero)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300">
                    Cloud Provider Substrate
                  </label>
                  <select
                    value={cloudProvider}
                    onChange={(e) => setCloudProvider(e.target.value as any)}
                    className="mt-1 w-full h-9 px-3 text-xs bg-slate-900 border border-slate-800 rounded-md text-white font-mono focus:outline-none focus:border-indigo-500"
                  >
                    <option value="aws">AWS (Amazon EKS)</option>
                    <option value="gcp">Google Cloud (GKE)</option>
                    <option value="azure">Microsoft Azure (AKS)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300">
                    Compute Sizing Profile
                  </label>
                  <select
                    value={sizingPreset}
                    onChange={(e) => setSizingPreset(e.target.value as any)}
                    className="mt-1 w-full h-9 px-3 text-xs bg-slate-900 border border-slate-800 rounded-md text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="lightweight">Lightweight (1-4 pods, 0.5 CPU / 1GB RAM)</option>
                    <option value="standard">Standard (3-8 pods, 1.0 CPU / 2GB RAM)</option>
                    <option value="high_throughput">High Throughput (6-20 pods, 2.0 CPU / 4GB RAM)</option>
                  </select>
                </div>
              </div>

              {/* Database Toggle */}
              <div className="p-4 rounded-lg bg-slate-900/60 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-white">Attach Managed RDS Aurora PostgreSQL</div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    Provisions encrypted RDS cluster with IAM auth and auto-rotated secrets
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={enableDatabase}
                  onChange={(e) => setEnableDatabase(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-indigo-500"
                />
              </div>
            </div>
          )}

          {/* STEP 3: IAC LIVE PREVIEW */}
          {currentStep === 3 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white">Infrastructure as Code Live Preview</h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Synthesized Terraform modules, Kubernetes manifests, and CI/CD pipelines
                  </p>
                </div>

                {/* Sub-tabs for code files */}
                <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-md text-xs font-mono">
                  <button
                    onClick={() => setActiveCodeTab('terraform')}
                    className={`px-2.5 py-1 rounded transition-colors ${
                      activeCodeTab === 'terraform' ? 'bg-slate-800 text-white' : 'text-slate-400'
                    }`}
                  >
                    main.tf
                  </button>
                  <button
                    onClick={() => setActiveCodeTab('kubernetes')}
                    className={`px-2.5 py-1 rounded transition-colors ${
                      activeCodeTab === 'kubernetes' ? 'bg-slate-800 text-white' : 'text-slate-400'
                    }`}
                  >
                    deployment.yaml
                  </button>
                  <button
                    onClick={() => setActiveCodeTab('cicd')}
                    className={`px-2.5 py-1 rounded transition-colors ${
                      activeCodeTab === 'cicd' ? 'bg-slate-800 text-white' : 'text-slate-400'
                    }`}
                  >
                    deploy.yaml
                  </button>
                </div>
              </div>

              {/* Code viewer */}
              <div className="rounded-lg border border-slate-800 bg-slate-950 overflow-hidden">
                <div className="px-4 py-2 border-b border-slate-850 bg-slate-900/60 flex items-center justify-between text-[11px] font-mono text-slate-400">
                  <span>
                    {activeCodeTab === 'terraform' && 'terraform/main.tf'}
                    {activeCodeTab === 'kubernetes' && 'k8s/deployment.yaml'}
                    {activeCodeTab === 'cicd' && '.github/workflows/deploy.yaml'}
                  </span>
                  <span>Generated dynamically</span>
                </div>
                <pre className="p-4 text-xs font-mono text-slate-300 overflow-x-auto whitespace-pre leading-relaxed max-h-72">
                  {activeCodeTab === 'terraform' && generatedTerraform}
                  {activeCodeTab === 'kubernetes' && generatedK8s}
                  {activeCodeTab === 'cicd' && generatedCicd}
                </pre>
              </div>

              {/* Infracost quick summary */}
              <div className="p-3.5 rounded-lg bg-indigo-950/20 border border-indigo-900/40 flex items-center justify-between text-xs font-mono">
                <span className="text-slate-300">
                  Estimated Monthly Cost Impact (Infracost)
                </span>
                <span className="text-emerald-400 font-bold text-sm">
                  +${calculatedCost}/month
                </span>
              </div>
            </div>
          )}

          {/* STEP 4: SECURITY GATES & POLICIES */}
          {currentStep === 4 && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-semibold text-white">Automated Security & Compliance Gates</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Static analysis, vulnerability audits, and policy enforcement before cloud provisioning
                </p>
              </div>

              <div className="space-y-3 pt-2">
                {[
                  {
                    tool: 'Trivy Scanner',
                    title: 'Container Base Image Vulnerability Check',
                    desc: 'Scanned distroless:nonroot-v1.23. 0 Critical, 0 High vulnerabilities found.',
                    status: 'pass',
                  },
                  {
                    tool: 'OPA Gatekeeper',
                    title: 'Pod Security Standard: Restricted Profile',
                    desc: 'Enforcing runAsNonRoot=true, readOnlyRootFilesystem=true, capabilities drop ALL.',
                    status: 'pass',
                  },
                  {
                    tool: 'Checkov IaC',
                    title: 'Terraform CIS Benchmark Compliance',
                    desc: 'VPC isolation verified. Encryption-at-rest with KMS Customer Managed Keys.',
                    status: 'pass',
                  },
                  {
                    tool: 'FinOps Guardrail',
                    title: 'Quarterly Team Budget Allocation Check',
                    desc: `Team "${ownerTeam}" has $4,200 unallocated budget remaining. Requested $${calculatedCost}/mo is approved.`,
                    status: 'pass',
                  },
                ].map((gate) => (
                  <div
                    key={gate.title}
                    className="p-3.5 rounded-lg bg-slate-900/60 border border-slate-800 flex items-start gap-3"
                  >
                    <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-white">{gate.title}</span>
                        <span className="text-[10px] font-mono text-emerald-400 uppercase font-bold">
                          Passed
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        {gate.desc}
                      </p>
                      <span className="text-[10px] text-slate-500 font-mono mt-1 block">
                        Engine: {gate.tool}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 5: PROVISIONING EXECUTION PIPELINE */}
          {currentStep === 5 && (
            <div className="space-y-5">
              <div>
                <h3 className="text-sm font-semibold text-white">
                  {activeProvisionJob?.status === 'completed'
                    ? 'Service Provisioned Successfully!'
                    : 'Executing Infrastructure Provisioning Pipeline...'}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5 font-mono">
                  Job ID: {activeProvisionJob?.id} · Target: {cloudProvider.toUpperCase()} / {environment}
                </p>
              </div>

              {/* Steps Progress */}
              <div className="space-y-2">
                {activeProvisionJob?.steps.map((st, idx) => (
                  <div
                    key={st.id}
                    className={`p-3 rounded-lg border transition-all flex items-center justify-between text-xs ${
                      st.status === 'completed'
                        ? 'bg-slate-900/40 border-slate-800 text-slate-300'
                        : st.status === 'running'
                        ? 'bg-indigo-950/30 border-indigo-500 text-white'
                        : 'bg-slate-950 border-slate-850 text-slate-600'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {st.status === 'completed' ? (
                        <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                      ) : st.status === 'running' ? (
                        <RefreshCw className="h-4 w-4 text-indigo-400 animate-spin shrink-0" />
                      ) : (
                        <div className="h-4 w-4 rounded-full border border-slate-700 shrink-0 flex items-center justify-center text-[10px] font-mono">
                          {idx + 1}
                        </div>
                      )}
                      <div>
                        <div className="font-semibold">{st.name}</div>
                        <div className="text-[11px] text-slate-400">{st.description}</div>
                      </div>
                    </div>
                    <span className="font-mono text-[10px] uppercase font-semibold">
                      {st.status}
                    </span>
                  </div>
                ))}
              </div>

              {/* Streaming Execution Logs */}
              <div>
                <span className="text-xs font-semibold text-slate-300">Live Provisioner Logs</span>
                <div className="mt-1.5 p-3 rounded-lg bg-black border border-slate-800 font-mono text-xs text-slate-300 h-44 overflow-y-auto space-y-1">
                  {activeProvisionJob?.logs.map((lg, i) => (
                    <div key={i} className="flex gap-2">
                      <span className="text-slate-600 select-none">{lg.timestamp}</span>
                      <span
                        className={
                          lg.level === 'success'
                            ? 'text-emerald-400'
                            : lg.level === 'warn'
                            ? 'text-amber-300'
                            : 'text-slate-300'
                        }
                      >
                        {lg.message}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Completion Artifacts */}
              {activeProvisionJob?.status === 'completed' && (
                <div className="p-4 rounded-lg bg-emerald-950/20 border border-emerald-900/50 space-y-3">
                  <div className="flex items-center gap-2 text-emerald-300 font-semibold text-xs">
                    <CheckCircle2 className="h-4 w-4" />
                    <span>Your service is live and ready for traffic!</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
                    <a
                      href={activeProvisionJob.outputs.ingressUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="p-2 rounded bg-slate-900 border border-slate-800 text-indigo-400 flex items-center justify-between hover:bg-slate-850"
                    >
                      <span>Endpoint URL</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                    <a
                      href={activeProvisionJob.outputs.argocdApp}
                      target="_blank"
                      rel="noreferrer"
                      className="p-2 rounded bg-slate-900 border border-slate-800 text-indigo-400 flex items-center justify-between hover:bg-slate-850"
                    >
                      <span>ArgoCD Dashboard</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Wizard Footer Controls */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-800 bg-slate-900/80">
          <div>
            {currentStep > 1 && currentStep < 5 && (
              <button
                onClick={() => setCurrentStep(currentStep - 1)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-md transition-colors"
              >
                <ArrowLeft className="h-3 w-3" />
                <span>Back</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-3">
            {currentStep < 4 && (
              <button
                onClick={() => setCurrentStep(currentStep + 1)}
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-md transition-colors"
              >
                <span>Continue</span>
                <ArrowRight className="h-3 w-3" />
              </button>
            )}

            {currentStep === 4 && (
              <button
                onClick={handleLaunchProvisioning}
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-md shadow-md shadow-indigo-600/30 transition-colors"
              >
                <span>Approve & Launch Provisioning</span>
                <ArrowRight className="h-3 w-3" />
              </button>
            )}

            {currentStep === 5 && activeProvisionJob?.status === 'completed' && (
              <button
                onClick={handleFinish}
                className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-md transition-colors"
              >
                View in Service Catalog
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
