import {
  ServiceEntity,
  GoldenPathTemplate,
  K8sCluster,
  K8sPod,
  TerraformWorkspace,
  CostRecommendation,
  PipelineRun,
  ActivityEvent,
} from '../types/idp';

export const INITIAL_SERVICES: ServiceEntity[] = [
  {
    id: 'auth-gateway',
    name: 'auth-gateway',
    displayName: 'Auth Gateway',
    description: 'High-throughput OAuth2 and OpenID Connect token verification and session exchange gateway.',
    kind: 'service',
    system: 'identity-platform',
    domain: 'Security & Auth',
    ownerTeam: 'SecOps Platform',
    tier: 'tier-1',
    lifecycle: 'production',
    language: 'go',
    repoUrl: 'https://github.com/enterprise/auth-gateway',
    docsUrl: 'https://docs.internal.net/services/auth-gateway',
    healthStatus: 'healthy',
    tags: ['oauth2', 'jwt', 'security', 'zero-trust'],
    lastDeployedAt: '18m ago',
    costMonthly: 412,
    costTrendPercent: -3.4,
    cluster: 'aws-us-east-1-prod',
    namespace: 'identity',
    replicas: {
      current: 8,
      target: 8,
      min: 4,
      max: 16,
    },
    resources: {
      cpuUsage: '1.42 cores',
      cpuRequest: '2.0 cores',
      cpuLimit: '4.0 cores',
      memoryUsage: '3.1 GB',
      memoryRequest: '4.0 GB',
      memoryLimit: '8.0 GB',
    },
    dependsOn: ['redis-sessions', 'vault-kms'],
    consumedBy: ['checkout-orchestrator', 'customer-portal', 'notification-hub'],
    providesApis: ['AuthV2SessionAPI', 'TokenValidatorgRPC'],
    gitopsSyncStatus: 'synced',
    terraformWorkspaceId: 'ws-auth-gw-prod',
    ciPipelineId: 'pipe-auth-1092',
  },
  {
    id: 'checkout-orchestrator',
    name: 'checkout-orchestrator',
    displayName: 'Checkout Orchestrator',
    description: 'Core commerce order saga manager, shopping cart state transitions, and tax computations.',
    kind: 'service',
    system: 'order-processing',
    domain: 'Core Commerce',
    ownerTeam: 'Checkout Core',
    tier: 'tier-1',
    lifecycle: 'production',
    language: 'typescript',
    repoUrl: 'https://github.com/enterprise/checkout-orchestrator',
    docsUrl: 'https://docs.internal.net/services/checkout-orchestrator',
    healthStatus: 'healthy',
    tags: ['ecommerce', 'cart', 'saga', 'aurora'],
    lastDeployedAt: '2h ago',
    costMonthly: 1240,
    costTrendPercent: 6.8,
    cluster: 'aws-us-east-1-prod',
    namespace: 'commerce',
    replicas: {
      current: 12,
      target: 12,
      min: 6,
      max: 24,
    },
    resources: {
      cpuUsage: '5.8 cores',
      cpuRequest: '8.0 cores',
      cpuLimit: '16.0 cores',
      memoryUsage: '14.2 GB',
      memoryRequest: '16.0 GB',
      memoryLimit: '24.0 GB',
    },
    dependsOn: ['auth-gateway', 'payment-service', 'inventory-worker', 'aurora-pg-commerce'],
    consumedBy: ['customer-portal', 'mobile-api-gw'],
    providesApis: ['CheckoutCartAPI', 'OrderSagaEvents'],
    gitopsSyncStatus: 'synced',
    terraformWorkspaceId: 'ws-checkout-prod',
    ciPipelineId: 'pipe-checkout-3411',
  },
  {
    id: 'payment-service',
    name: 'payment-service',
    displayName: 'Payment Service',
    description: 'PCI-DSS certified payment gateway interface connecting Stripe, Adyen, and merchant banks.',
    kind: 'service',
    system: 'finance-rails',
    domain: 'FinTech',
    ownerTeam: 'FinPlatform',
    tier: 'tier-1',
    lifecycle: 'production',
    language: 'rust',
    repoUrl: 'https://github.com/enterprise/payment-service',
    docsUrl: 'https://docs.internal.net/services/payment-service',
    healthStatus: 'healthy',
    tags: ['payments', 'pci-dss', 'stripe', 'audit-ready'],
    lastDeployedAt: '1d ago',
    costMonthly: 590,
    costTrendPercent: 1.2,
    cluster: 'aws-us-east-1-prod',
    namespace: 'pci-isolated',
    replicas: {
      current: 6,
      target: 6,
      min: 4,
      max: 12,
    },
    resources: {
      cpuUsage: '0.88 cores',
      cpuRequest: '1.5 cores',
      cpuLimit: '3.0 cores',
      memoryUsage: '1.8 GB',
      memoryRequest: '2.5 GB',
      memoryLimit: '4.0 GB',
    },
    dependsOn: ['vault-kms', 'dynamodb-ledger'],
    consumedBy: ['checkout-orchestrator'],
    providesApis: ['PaymentIntentAPI', 'RefundWebhookHandler'],
    gitopsSyncStatus: 'synced',
    terraformWorkspaceId: 'ws-payment-prod',
    ciPipelineId: 'pipe-payment-884',
  },
  {
    id: 'inventory-worker',
    name: 'inventory-worker',
    displayName: 'Inventory Worker',
    description: 'Kafka event-driven consumer syncing warehouse stock allocations and inventory locks.',
    kind: 'pipeline',
    system: 'fulfillment',
    domain: 'Logistics',
    ownerTeam: 'SupplyChain Tech',
    tier: 'tier-2',
    lifecycle: 'production',
    language: 'python',
    repoUrl: 'https://github.com/enterprise/inventory-worker',
    docsUrl: 'https://docs.internal.net/services/inventory-worker',
    healthStatus: 'warning',
    tags: ['kafka', 'consumer', 'keda', 'warehouse'],
    lastDeployedAt: '4d ago',
    costMonthly: 420,
    costTrendPercent: 14.5,
    cluster: 'aws-eu-west-1-prod',
    namespace: 'fulfillment',
    replicas: {
      current: 5,
      target: 5,
      min: 2,
      max: 10,
    },
    resources: {
      cpuUsage: '0.45 cores',
      cpuRequest: '3.0 cores',
      cpuLimit: '6.0 cores',
      memoryUsage: '2.4 GB',
      memoryRequest: '8.0 GB',
      memoryLimit: '12.0 GB',
    },
    dependsOn: ['kafka-cluster-prod', 'aurora-pg-commerce'],
    consumedBy: ['checkout-orchestrator'],
    providesApis: ['StockReservationEvents'],
    gitopsSyncStatus: 'synced',
    terraformWorkspaceId: 'ws-inventory-prod',
    ciPipelineId: 'pipe-inv-512',
  },
  {
    id: 'notification-hub',
    name: 'notification-hub',
    displayName: 'Notification Hub',
    description: 'Multi-channel delivery engine dispatching transactional email, SMS, and APNs/FCM push notifications.',
    kind: 'service',
    system: 'comms',
    domain: 'Engagement',
    ownerTeam: 'Growth Eng',
    tier: 'tier-2',
    lifecycle: 'production',
    language: 'go',
    repoUrl: 'https://github.com/enterprise/notification-hub',
    docsUrl: 'https://docs.internal.net/services/notification-hub',
    healthStatus: 'healthy',
    tags: ['sqs', 'sendgrid', 'push', 'webhooks'],
    lastDeployedAt: '12h ago',
    costMonthly: 215,
    costTrendPercent: -1.8,
    cluster: 'gcp-us-central-prod',
    namespace: 'comms',
    replicas: {
      current: 4,
      target: 4,
      min: 2,
      max: 8,
    },
    resources: {
      cpuUsage: '0.62 cores',
      cpuRequest: '1.0 cores',
      cpuLimit: '2.0 cores',
      memoryUsage: '1.2 GB',
      memoryRequest: '2.0 GB',
      memoryLimit: '4.0 GB',
    },
    dependsOn: ['sqs-queue-notifications'],
    consumedBy: ['checkout-orchestrator', 'auth-gateway'],
    providesApis: ['DispatchNotificationAPI'],
    gitopsSyncStatus: 'synced',
    terraformWorkspaceId: 'ws-notify-prod',
    ciPipelineId: 'pipe-notif-902',
  },
  {
    id: 'analytics-streaming',
    name: 'analytics-streaming',
    displayName: 'Analytics Streaming',
    description: 'High-volume telemetry ingestion pipeline feeding ClickHouse OLAP tables and real-time dashboards.',
    kind: 'pipeline',
    system: 'data-platform',
    domain: 'Data Analytics',
    ownerTeam: 'Data Eng',
    tier: 'tier-2',
    lifecycle: 'production',
    language: 'python',
    repoUrl: 'https://github.com/enterprise/analytics-streaming',
    docsUrl: 'https://docs.internal.net/services/analytics-streaming',
    healthStatus: 'healthy',
    tags: ['clickhouse', 'kafka', 'streaming', 'olap'],
    lastDeployedAt: '3d ago',
    costMonthly: 2480,
    costTrendPercent: 4.2,
    cluster: 'aws-us-east-1-prod',
    namespace: 'data-lake',
    replicas: {
      current: 16,
      target: 16,
      min: 8,
      max: 32,
    },
    resources: {
      cpuUsage: '14.5 cores',
      cpuRequest: '16.0 cores',
      cpuLimit: '32.0 cores',
      memoryUsage: '38.0 GB',
      memoryRequest: '48.0 GB',
      memoryLimit: '64.0 GB',
    },
    dependsOn: ['kafka-cluster-prod', 'clickhouse-cluster'],
    consumedBy: ['bi-dashboards'],
    providesApis: ['EventIngestionEndpoint'],
    gitopsSyncStatus: 'synced',
    terraformWorkspaceId: 'ws-analytics-prod',
    ciPipelineId: 'pipe-analytics-112',
  },
  {
    id: 'customer-portal-web',
    name: 'customer-portal-web',
    displayName: 'Customer Portal Web',
    description: 'Customer facing Next.js server-side rendered application with edge caching on Cloudflare.',
    kind: 'website',
    system: 'frontend-apps',
    domain: 'Core Commerce',
    ownerTeam: 'Frontend Platform',
    tier: 'tier-1',
    lifecycle: 'production',
    language: 'typescript',
    repoUrl: 'https://github.com/enterprise/customer-portal-web',
    docsUrl: 'https://docs.internal.net/services/customer-portal-web',
    healthStatus: 'healthy',
    tags: ['nextjs', 'ssr', 'react', 'edge-cdn'],
    lastDeployedAt: '45m ago',
    costMonthly: 180,
    costTrendPercent: 0.5,
    cluster: 'aws-us-east-1-prod',
    namespace: 'web-frontends',
    replicas: {
      current: 6,
      target: 6,
      min: 3,
      max: 15,
    },
    resources: {
      cpuUsage: '1.1 cores',
      cpuRequest: '1.5 cores',
      cpuLimit: '3.0 cores',
      memoryUsage: '2.8 GB',
      memoryRequest: '4.0 GB',
      memoryLimit: '6.0 GB',
    },
    dependsOn: ['auth-gateway', 'checkout-orchestrator'],
    consumedBy: [],
    providesApis: ['WebUserInterface'],
    gitopsSyncStatus: 'synced',
    terraformWorkspaceId: 'ws-portal-prod',
    ciPipelineId: 'pipe-portal-773',
  },
  {
    id: 'ai-search-indexer',
    name: 'ai-search-indexer',
    displayName: 'AI Search Indexer',
    description: 'Vector embeddings generator utilizing GPU worker nodes to index catalog items into Qdrant.',
    kind: 'service',
    system: 'discovery-ml',
    domain: 'Search & ML',
    ownerTeam: 'Applied ML',
    tier: 'tier-2',
    lifecycle: 'production',
    language: 'python',
    repoUrl: 'https://github.com/enterprise/ai-search-indexer',
    docsUrl: 'https://docs.internal.net/services/ai-search-indexer',
    healthStatus: 'degraded',
    tags: ['gpu', 'qdrant', 'embeddings', 'pytorch'],
    lastDeployedAt: '5h ago',
    costMonthly: 1940,
    costTrendPercent: 22.1,
    cluster: 'gcp-us-central-prod',
    namespace: 'ml-inference',
    replicas: {
      current: 3,
      target: 4,
      min: 2,
      max: 8,
    },
    resources: {
      cpuUsage: '6.4 cores',
      cpuRequest: '8.0 cores',
      cpuLimit: '12.0 cores',
      memoryUsage: '22.0 GB',
      memoryRequest: '28.0 GB',
      memoryLimit: '32.0 GB',
    },
    dependsOn: ['qdrant-vector-db', 'aurora-pg-commerce'],
    consumedBy: ['checkout-orchestrator', 'customer-portal-web'],
    providesApis: ['VectorSearchQueryAPI', 'EmbedBatchEndpoint'],
    gitopsSyncStatus: 'outofsync',
    terraformWorkspaceId: 'ws-indexer-prod',
    ciPipelineId: 'pipe-ml-404',
  },
];

export const GOLDEN_PATH_TEMPLATES: GoldenPathTemplate[] = [
  {
    id: 'tpl-go-grpc-microservice',
    title: 'Production Microservice (Go + gRPC + K8s)',
    description: 'Industrial-grade Go service scaffolded with gRPC/REST gateway, OpenTelemetry tracing, Datadog sidecar, and K8s HPA auto-scaling.',
    category: 'backend',
    tags: ['Go 1.23', 'gRPC', 'Kubernetes HPA', 'OpenTelemetry', 'ArgoCD'],
    author: 'Platform Architecture Team',
    timeToDeploy: '~3 mins',
    cloudSupport: ['aws', 'gcp'],
    estimatedMonthlyCost: 85,
    fields: [
      {
        id: 'serviceName',
        label: 'Service Name',
        description: 'Lowercase alphanumeric slug with hyphens (e.g. order-dispatcher)',
        type: 'text',
        defaultValue: 'my-microservice',
        required: true,
      },
      {
        id: 'ownerTeam',
        label: 'Owner Team',
        description: 'Engineering squad responsible for on-call and maintenance',
        type: 'select',
        defaultValue: 'Checkout Core',
        options: [
          { label: 'Checkout Core', value: 'Checkout Core' },
          { label: 'SecOps Platform', value: 'SecOps Platform' },
          { label: 'FinPlatform', value: 'FinPlatform' },
          { label: 'SupplyChain Tech', value: 'SupplyChain Tech' },
          { label: 'Data Eng', value: 'Data Eng' },
          { label: 'Applied ML', value: 'Applied ML' },
        ],
        required: true,
      },
      {
        id: 'environment',
        label: 'Target Environment',
        description: 'Deployment tier and cluster target',
        type: 'select',
        defaultValue: 'production',
        options: [
          { label: 'Production (Multi-AZ, strict SLO)', value: 'production' },
          { label: 'Staging (Single-AZ, test traffic)', value: 'staging' },
          { label: 'Development (Scale-to-zero enabled)', value: 'development' },
        ],
        required: true,
      },
      {
        id: 'cloudProvider',
        label: 'Cloud Infrastructure Provider',
        description: 'Underlying cloud runtime substrate',
        type: 'select',
        defaultValue: 'aws',
        options: [
          { label: 'AWS (EKS us-east-1)', value: 'aws' },
          { label: 'Google Cloud (GKE us-central1)', value: 'gcp' },
          { label: 'Microsoft Azure (AKS eastus)', value: 'azure' },
        ],
        required: true,
      },
      {
        id: 'enablePostgres',
        label: 'Provision Dedicated RDS Aurora Database',
        description: 'Attaches dedicated PostgreSQL instance with auto-generated IAM role and Vault secrets rotation',
        type: 'boolean',
        defaultValue: false,
      },
      {
        id: 'replicaPreset',
        label: 'Workload Sizing & Replicas',
        description: 'Baseline compute provisioning profile',
        type: 'select',
        defaultValue: 'standard',
        options: [
          { label: 'Lightweight (1-4 pods, 0.5 CPU / 1GB RAM) - $45/mo', value: 'lightweight' },
          { label: 'Standard (3-8 pods, 1.0 CPU / 2GB RAM) - $85/mo', value: 'standard' },
          { label: 'High Throughput (6-20 pods, 2.0 CPU / 4GB RAM) - $190/mo', value: 'high_throughput' },
        ],
      },
    ],
    terraformFiles: [
      {
        filename: 'main.tf',
        content: `terraform {
  required_version = ">= 1.7.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.40"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.26"
    }
  }
}

module "service_workload" {
  source = "git::https://github.com/enterprise/terraform-modules.git//eks-service-workload?ref=v3.2.0"

  service_name        = var.service_name
  namespace           = var.namespace
  environment         = var.environment
  cluster_name        = var.eks_cluster_name
  min_replicas        = var.min_replicas
  max_replicas        = var.max_replicas
  cpu_request         = "1000m"
  memory_request      = "2048Mi"
  datadog_apm_enabled = true
  enable_vault_token  = true

  tags = {
    OwnerTeam   = var.owner_team
    CostCenter  = "CoreEngineering"
    ManagedBy   = "Nexus-IDP"
  }
}`,
      },
      {
        filename: 'variables.tf',
        content: `variable "service_name" {
  type        = string
  description = "Unique service identifier"
}

variable "environment" {
  type        = string
  default     = "production"
}

variable "owner_team" {
  type        = string
}

variable "min_replicas" {
  type        = number
  default     = 3
}

variable "max_replicas" {
  type        = number
  default     = 8
}`,
      },
    ],
    k8sFiles: [
      {
        filename: 'deployment.yaml',
        content: `apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ service_name }}
  namespace: {{ namespace }}
  labels:
    app.kubernetes.io/name: {{ service_name }}
    app.kubernetes.io/part-of: nexus-platform
spec:
  replicas: 3
  selector:
    matchLabels:
      app: {{ service_name }}
  template:
    metadata:
      labels:
        app: {{ service_name }}
      annotations:
        ad.datadoghq.com/{{ service_name }}.logs: '[{"source":"go","service":"{{ service_name }}"}]'
    spec:
      serviceAccountName: {{ service_name }}-sa
      containers:
      - name: app
        image: 253687723639.dkr.ecr.us-east-1.amazonaws.com/{{ service_name }}:latest
        ports:
        - containerPort: 8080
          name: http
        - containerPort: 9090
          name: grpc
        resources:
          requests:
            cpu: 1000m
            memory: 2048Mi
          limits:
            cpu: 2000m
            memory: 4096Mi
        livenessProbe:
          httpGet:
            path: /healthz
            port: 8080
          initialDelaySeconds: 5
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8080
          initialDelaySeconds: 2
          periodSeconds: 5`,
      },
      {
        filename: 'hpa.yaml',
        content: `apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: {{ service_name }}-hpa
  namespace: {{ namespace }}
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: {{ service_name }}
  minReplicas: 3
  maxReplicas: 8
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 75`,
      },
    ],
    cicdFiles: [
      {
        filename: '.github/workflows/deploy.yaml',
        content: `name: Build & GitOps Sync
on:
  push:
    branches: [main]

jobs:
  build-and-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-go@v5
        with:
          go-version: '1.23'
      - run: go test -v -race -cover ./...
      - name: Build and Push Docker image
        run: |
          docker build -t ecr.nexus.net/{{ service_name }}:$GITHUB_SHA .
          docker push ecr.nexus.net/{{ service_name }}:$GITHUB_SHA
      - name: Sync ArgoCD Application
        uses: enterprise/argocd-sync-action@v2
        with:
          app-name: {{ service_name }}-prod
          token: \${{ secrets.ARGOCD_TOKEN }}`,
      },
    ],
    securityPolicies: [
      {
        name: 'Trivy Container CVE Vulnerability Gate',
        tool: 'Trivy',
        status: 'pass',
        description: 'Zero CRITICAL or HIGH vulnerabilities detected in base Distroless Go image.',
      },
      {
        name: 'OPA Gatekeeper Non-Root Execution Enforcement',
        tool: 'OPA Gatekeeper',
        status: 'pass',
        description: 'Workload enforces runAsNonRoot=true and readOnlyRootFilesystem=true.',
      },
      {
        name: 'FinOps Budget Allocation Check',
        tool: 'FinOps Guardrail',
        status: 'pass',
        description: 'Estimated $85/mo falls within team quarterly unallocated allocation ($450/mo remaining).',
      },
    ],
  },
  {
    id: 'tpl-nextjs-web',
    title: 'Next.js 15 Web Application (Node + CDN + ArgoCD)',
    description: 'High-performance React application scaffolded with TypeScript, Tailwind CSS, Edge runtime middleware, and automatic Cloudflare CDN invalidation.',
    category: 'frontend',
    tags: ['Next.js 15', 'TypeScript', 'Tailwind', 'Cloudflare Edge', 'ArgoCD'],
    author: 'Frontend Platform Core',
    timeToDeploy: '~2.5 mins',
    cloudSupport: ['aws', 'gcp', 'azure'],
    estimatedMonthlyCost: 65,
    fields: [
      {
        id: 'serviceName',
        label: 'Application Slug',
        description: 'Web portal slug (e.g. merchant-dashboard)',
        type: 'text',
        defaultValue: 'merchant-portal',
        required: true,
      },
      {
        id: 'ownerTeam',
        label: 'Owner Team',
        description: 'Product UI team',
        type: 'select',
        defaultValue: 'Frontend Platform',
        options: [
          { label: 'Frontend Platform', value: 'Frontend Platform' },
          { label: 'Checkout Core', value: 'Checkout Core' },
          { label: 'Growth Eng', value: 'Growth Eng' },
        ],
        required: true,
      },
      {
        id: 'publicCustomDomain',
        label: 'Allocate Custom DNS Domain',
        description: 'Generates ACM SSL certificate and Route53 DNS alias automatically',
        type: 'boolean',
        defaultValue: true,
      },
    ],
    terraformFiles: [
      {
        filename: 'cdn.tf',
        content: `resource "aws_cloudfront_distribution" "frontend" {
  enabled             = true
  is_ipv6_enabled     = true
  default_root_object = "index.html"
  price_class         = "PriceClass_100"

  origin {
    domain_name = var.k8s_ingress_hostname
    origin_id   = "k8s-origin"
    custom_origin_config {
      http_port              = 80
      https_port             = 443
      origin_protocol_policy = "https-only"
      origin_ssl_protocols   = ["TLSv1.2"]
    }
  }
}`,
      },
    ],
    k8sFiles: [
      {
        filename: 'ingress.yaml',
        content: `apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: {{ service_name }}-ingress
  annotations:
    kubernetes.io/ingress.class: nginx
    cert-manager.io/cluster-issuer: letsencrypt-prod
spec:
  rules:
  - host: {{ service_name }}.internal.net
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: {{ service_name }}
            port:
              number: 3000`,
      },
    ],
    cicdFiles: [
      {
        filename: '.github/workflows/nextjs-deploy.yaml',
        content: `name: Deploy Next.js Web App
on: [push]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: npm ci && npm run build
      - name: Deploy to Kubernetes Cluster
        run: echo "Promoting container tag to GitOps repo"`,
      },
    ],
    securityPolicies: [
      {
        name: 'TLS 1.3 Ingress Encryption Enforcement',
        tool: 'Checkov',
        status: 'pass',
        description: 'Ingress configuration mandates TLS 1.2+ with HSTS headers.',
      },
      {
        name: 'Trivy Dependency Audit',
        tool: 'Trivy',
        status: 'pass',
        description: 'Zero high severity npm vulnerabilities found.',
      },
    ],
  },
  {
    id: 'tpl-kafka-consumer',
    title: 'Event-Driven Consumer (Python + Kafka + KEDA)',
    description: 'Auto-scaling async event pipeline powered by Strimzi Kafka operator and KEDA queue-lag autoscaling.',
    category: 'data',
    tags: ['Python 3.12', 'Apache Kafka', 'KEDA Scaler', 'Dead-Letter Queue'],
    author: 'Data Platform Team',
    timeToDeploy: '~4 mins',
    cloudSupport: ['aws', 'gcp'],
    estimatedMonthlyCost: 110,
    fields: [
      {
        id: 'serviceName',
        label: 'Pipeline Name',
        description: 'E.g. telemetry-enricher',
        type: 'text',
        defaultValue: 'stock-event-consumer',
        required: true,
      },
      {
        id: 'kafkaTopic',
        label: 'Kafka Subscription Topic',
        description: 'Primary topic to consume from',
        type: 'select',
        defaultValue: 'orders.v1.events',
        options: [
          { label: 'orders.v1.events', value: 'orders.v1.events' },
          { label: 'payments.v2.settlements', value: 'payments.v2.settlements' },
          { label: 'inventory.stock.allocations', value: 'inventory.stock.allocations' },
          { label: 'user.activity.telemetry', value: 'user.activity.telemetry' },
        ],
      },
    ],
    terraformFiles: [],
    k8sFiles: [],
    cicdFiles: [],
    securityPolicies: [
      {
        name: 'Dead-Letter-Queue Mandatory Retention',
        tool: 'OPA Gatekeeper',
        status: 'pass',
        description: 'Kafka consumer manifests must bind a DLQ with 14-day retention.',
      },
    ],
  },
  {
    id: 'tpl-managed-rds-postgres',
    title: 'Managed RDS Aurora PostgreSQL (Multi-AZ + IAM Auth)',
    description: 'Highly-available enterprise database module with automated hourly snapshots, KMS customer-managed key encryption, and Performance Insights.',
    category: 'infra',
    tags: ['PostgreSQL 16', 'AWS Aurora', 'KMS Encryption', 'IAM Auth'],
    author: 'Database Infrastructure SRE',
    timeToDeploy: '~6 mins',
    cloudSupport: ['aws'],
    estimatedMonthlyCost: 260,
    fields: [
      {
        id: 'serviceName',
        label: 'Database Cluster Identifier',
        description: 'E.g. db-commerce-core',
        type: 'text',
        defaultValue: 'db-orders-cluster',
        required: true,
      },
      {
        id: 'instanceClass',
        label: 'Instance Compute Sizing',
        description: 'Aurora Serverless v2 or provisioned class',
        type: 'select',
        defaultValue: 'db.r6g.large',
        options: [
          { label: 'db.t4g.medium (2 vCPU, 4GB RAM) - $68/mo', value: 'db.t4g.medium' },
          { label: 'db.r6g.large (2 vCPU, 16GB RAM) - $260/mo', value: 'db.r6g.large' },
          { label: 'db.r6g.2xlarge (8 vCPU, 64GB RAM) - $890/mo', value: 'db.r6g.2xlarge' },
        ],
      },
    ],
    terraformFiles: [],
    k8sFiles: [],
    cicdFiles: [],
    securityPolicies: [
      {
        name: 'At-Rest Storage KMS Encryption',
        tool: 'Checkov',
        status: 'pass',
        description: 'Storage must be encrypted with Customer Managed Key (CMK).',
      },
      {
        name: 'No Public IP Exposure',
        tool: 'Checkov',
        status: 'pass',
        description: 'DB instances reside strictly in private DB subnets without IGW route.',
      },
    ],
  },
];

export const INITIAL_CLUSTERS: K8sCluster[] = [
  {
    id: 'aws-us-east-1-prod',
    name: 'aws-us-east-1-prod',
    provider: 'aws-eks',
    region: 'us-east-1',
    version: 'v1.30.2-eks',
    nodeCount: 18,
    cpuAllocatedPercent: 68,
    memAllocatedPercent: 74,
    status: 'healthy',
    namespaces: ['default', 'identity', 'commerce', 'pci-isolated', 'web-frontends', 'data-lake'],
    monthlyCost: 4890,
  },
  {
    id: 'aws-eu-west-1-prod',
    name: 'aws-eu-west-1-prod',
    provider: 'aws-eks',
    region: 'eu-west-1',
    version: 'v1.30.2-eks',
    nodeCount: 8,
    cpuAllocatedPercent: 42,
    memAllocatedPercent: 51,
    status: 'healthy',
    namespaces: ['default', 'fulfillment', 'billing-eu'],
    monthlyCost: 2180,
  },
  {
    id: 'gcp-us-central-prod',
    name: 'gcp-us-central-prod',
    provider: 'gcp-gke',
    region: 'us-central1',
    version: 'v1.30.1-gke.1200',
    nodeCount: 12,
    cpuAllocatedPercent: 84,
    memAllocatedPercent: 88,
    status: 'warning',
    namespaces: ['default', 'ml-inference', 'comms'],
    monthlyCost: 3450,
  },
  {
    id: 'aws-us-west-2-staging',
    name: 'aws-us-west-2-staging',
    provider: 'aws-eks',
    region: 'us-west-2',
    version: 'v1.31.0-eks.preview',
    nodeCount: 4,
    cpuAllocatedPercent: 28,
    memAllocatedPercent: 32,
    status: 'healthy',
    namespaces: ['default', 'staging-apps', 'qa-sandbox'],
    monthlyCost: 890,
  },
];

export const INITIAL_PODS: K8sPod[] = [
  {
    name: 'auth-gateway-7b8f964dc-8klq2',
    namespace: 'identity',
    status: 'Running',
    restarts: 0,
    age: '4d 12h',
    cpuUsage: '185m',
    memUsage: '412Mi',
    ip: '10.244.3.41',
    node: 'ip-10-0-12-88.ec2.internal',
    logs: [
      '[INFO] 2026-09-28T22:30:01Z [Auth] Initializing OpenID Connect keyset cache (provider: Okta)',
      '[INFO] 2026-09-28T22:30:02Z [HTTP] Listening on :8080 (read_timeout=5s, idle_timeout=60s)',
      '[INFO] 2026-09-28T22:30:02Z [gRPC] Starting token validation interceptor on :9090',
      '[INFO] 2026-09-28T22:32:15Z [Metrics] Exported 42,910 span traces to Datadog agent in 1.4ms',
      '[INFO] 2026-09-28T22:35:40Z [Session] Redis connection pool healthy: 48/50 connections active',
    ],
  },
  {
    name: 'auth-gateway-7b8f964dc-p9xrt',
    namespace: 'identity',
    status: 'Running',
    restarts: 0,
    age: '4d 12h',
    cpuUsage: '172m',
    memUsage: '398Mi',
    ip: '10.244.5.19',
    node: 'ip-10-0-12-89.ec2.internal',
    logs: [
      '[INFO] 2026-09-28T22:31:00Z [Auth] Ingress healthcheck probes reporting 200 OK',
      '[INFO] 2026-09-28T22:34:11Z [Token] Exchanged 1,290 JWT assertion claims (avg latency 3.1ms)',
    ],
  },
  {
    name: 'checkout-orchestrator-665cd98-v2n5k',
    namespace: 'commerce',
    status: 'Running',
    restarts: 1,
    age: '2d 6h',
    cpuUsage: '520m',
    memUsage: '1.2Gi',
    ip: '10.244.2.14',
    node: 'ip-10-0-12-88.ec2.internal',
    logs: [
      '[INFO] 2026-09-28T22:20:00Z [Saga] Initializing checkout saga coordinator v3.8.1',
      '[INFO] 2026-09-28T22:22:45Z [DB] Aurora connection pool pool_size=32 active=14 max=64',
      '[INFO] 2026-09-28T22:28:10Z [Cart] Completed order_id=ord_998124 total=$149.50 in 112ms',
    ],
  },
  {
    name: 'ai-search-indexer-849cfd-7xmzp',
    namespace: 'ml-inference',
    status: 'CrashLoopBackOff',
    restarts: 14,
    age: '1h 14m',
    cpuUsage: '1900m',
    memUsage: '7.8Gi',
    ip: '10.244.7.99',
    node: 'gke-gpu-a100-pool-91',
    logs: [
      '[INFO] 2026-09-28T22:15:00Z [CUDA] Detected NVIDIA A100-SXM4-40GB GPU (Driver 535.154.05)',
      '[INFO] 2026-09-28T22:16:30Z [PyTorch] Loading text-embedding-3-large weights from checkpoint',
      '[WARN] 2026-09-28T22:18:10Z [Memory] GPU VRAM pressure: 38.2GB / 40.0GB allocated (95.5%)',
      '[ERROR] 2026-09-28T22:18:44Z [CUDA] torch.cuda.OutOfMemoryError: CUDA out of memory. Tried to allocate 2.40 GiB (GPU 0; 39.56 GiB total capacity)',
      '[FATAL] 2026-09-28T22:18:45Z [Process] Terminating container with exit code 137 (OOMKilled)',
    ],
  },
  {
    name: 'inventory-worker-559d8-9zzkx',
    namespace: 'fulfillment',
    status: 'Running',
    restarts: 0,
    age: '7d 3h',
    cpuUsage: '90m',
    memUsage: '480Mi',
    ip: '10.244.1.72',
    node: 'ip-10-0-14-12.ec2.internal',
    logs: [
      '[INFO] 2026-09-28T22:10:00Z [Kafka] Consumer group fulfillment-stock-cg rebalanced partition 0-11',
      '[INFO] 2026-09-28T22:15:33Z [KEDA] Metric lag count: 14 msgs (below threshold 500, no scale-up needed)',
    ],
  },
];

export const INITIAL_WORKSPACES: TerraformWorkspace[] = [
  {
    id: 'ws-auth-gw-prod',
    name: 'prod-us-east-1/auth-gateway',
    environment: 'production',
    stateVersion: 'v4.11.0',
    lastRunId: 'run-99824',
    lastRunTime: '2 hours ago',
    driftDetected: false,
    resourcesCount: 24,
    monthlyCost: 412,
    planPending: false,
    repoPath: 'terraform/environments/prod/auth-gateway',
    lockStatus: 'unlocked',
    managedResources: [
      { type: 'aws_iam_role', name: 'service_sa_role', status: 'created', id: 'arn:aws:iam::253687723639:role/auth-gw-prod' },
      { type: 'kubernetes_service_account', name: 'auth_sa', status: 'created', id: 'identity/auth-gateway-sa' },
      { type: 'aws_security_group', name: 'ingress_sg', status: 'created', id: 'sg-08a9f24300bb' },
      { type: 'aws_route53_record', name: 'auth_api_dns', status: 'created', id: 'Z102938491_auth.internal.net' },
    ],
    planDiff: `# Terraform Plan output (No changes required - Infrastructure up to date)
aws_iam_role.service_sa_role: Refreshing state... [id=arn:aws:iam::253687723639:role/auth-gw-prod]
kubernetes_service_account.auth_sa: Refreshing state... [id=identity/auth-gateway-sa]

No changes. Your infrastructure matches the configuration.
Terraform has compared your real infrastructure against your configuration and found no differences.`,
  },
  {
    id: 'ws-checkout-prod',
    name: 'prod-us-east-1/checkout-orchestrator',
    environment: 'production',
    stateVersion: 'v5.2.1',
    lastRunId: 'run-99712',
    lastRunTime: '1 day ago',
    driftDetected: false,
    resourcesCount: 38,
    monthlyCost: 1240,
    planPending: false,
    repoPath: 'terraform/environments/prod/checkout-orchestrator',
    lockStatus: 'unlocked',
    managedResources: [
      { type: 'aws_rds_cluster_instance', name: 'aurora_writer', status: 'created', id: 'aurora-checkout-writer' },
      { type: 'aws_rds_cluster_instance', name: 'aurora_reader', status: 'created', id: 'aurora-checkout-reader' },
      { type: 'aws_elasticache_replication_group', name: 'cart_cache', status: 'created', id: 'tg-redis-cart' },
      { type: 'kubernetes_deployment', name: 'checkout_app', status: 'created', id: 'commerce/checkout-orchestrator' },
    ],
    planDiff: `# Terraform Plan (Pending verification)
~ module.aurora.aws_rds_cluster_parameter_group.pg
  ~ parameter {
      name  = "max_connections"
      value = "2000" -> "4000"
    }

Plan: 0 to add, 1 to change, 0 to destroy.`,
  },
  {
    id: 'ws-inventory-prod',
    name: 'prod-eu-west-1/inventory-worker',
    environment: 'production',
    stateVersion: 'v3.1.0',
    lastRunId: 'run-99401',
    lastRunTime: '4 days ago',
    driftDetected: true,
    resourcesCount: 16,
    monthlyCost: 420,
    planPending: true,
    repoPath: 'terraform/environments/prod/inventory-worker',
    lockStatus: 'unlocked',
    managedResources: [
      { type: 'kubernetes_deployment', name: 'inventory_consumer', status: 'drifted', id: 'fulfillment/inventory-worker' },
      { type: 'aws_sqs_queue', name: 'dead_letter_queue', status: 'created', id: 'https://sqs.eu-west-1.amazonaws.com/dlq-inv' },
    ],
    planDiff: `# Drift detected! Outside-of-Terraform change found:
~ kubernetes_deployment.inventory_consumer
  ~ spec.template.spec.containers[0].resources.requests.cpu
    - "3000m" (configured in code)
    + "1000m" (actual remote state modified manually in cluster)

Recommendation: Re-apply configuration or update repository spec to reflect downsized CPU requests.`,
  },
];

export const INITIAL_COST_RECOMMENDATIONS: CostRecommendation[] = [
  {
    id: 'rec-01',
    serviceId: 'inventory-worker',
    serviceName: 'inventory-worker',
    title: 'Downsize Over-Provisioned CPU Requests',
    description: 'Inventory Worker is requesting 3.0 cores per replica but peak 99th percentile utilization over 30 days is only 0.45 cores. Downsizing to 1.0 core frees unreserved node capacity.',
    potentialSavingsMonthly: 185,
    type: 'downsize_cpu',
    difficulty: 'easy',
    status: 'available',
  },
  {
    id: 'rec-02',
    serviceId: 'ai-search-indexer',
    serviceName: 'ai-search-indexer',
    title: 'Migrate GPU Inference Workers to Spot Instances',
    description: 'The embedding generation job is tolerant of preemptible nodes with checkpointing. Switching to GKE Spot GPU node pool yields a 65% discount on compute costs.',
    potentialSavingsMonthly: 720,
    type: 'spot_migration',
    difficulty: 'moderate',
    status: 'available',
  },
  {
    id: 'rec-03',
    serviceId: 'analytics-streaming',
    serviceName: 'analytics-streaming',
    title: 'Consolidate Unattached EBS gp3 Volumes',
    description: 'Found 6 unattached gp3 storage volumes lingering from decommissioned ClickHouse rebalancing tasks totaling 4.8 TB.',
    potentialSavingsMonthly: 384,
    type: 'unattached_volume',
    difficulty: 'easy',
    status: 'available',
  },
];

export const INITIAL_PIPELINES: PipelineRun[] = [
  {
    id: 'pipe-auth-1092',
    serviceId: 'auth-gateway',
    serviceName: 'auth-gateway',
    branch: 'main',
    commitHash: 'a71f04b',
    commitMessage: 'feat(oauth): add token introspection caching layer',
    author: 'elena.rostova@nexus.internal',
    status: 'success',
    duration: '2m 14s',
    startedAt: '18m ago',
    stages: [
      { name: 'Lint & Vet', status: 'success', duration: '14s' },
      { name: 'Unit & Race Tests', status: 'success', duration: '42s' },
      { name: 'Trivy Container Scan', status: 'success', duration: '28s' },
      { name: 'ArgoCD Sync (Prod)', status: 'success', duration: '50s' },
    ],
  },
  {
    id: 'pipe-checkout-3411',
    serviceId: 'checkout-orchestrator',
    serviceName: 'checkout-orchestrator',
    branch: 'main',
    commitHash: 'e48b91a',
    commitMessage: 'fix(tax): handle multi-currency decimal rounding edge case',
    author: 'marcus.chen@nexus.internal',
    status: 'success',
    duration: '3m 48s',
    startedAt: '2h ago',
    stages: [
      { name: 'Lint & Typecheck', status: 'success', duration: '22s' },
      { name: 'Jest Unit Tests', status: 'success', duration: '1m 10s' },
      { name: 'Docker Build & Push', status: 'success', duration: '1m 20s' },
      { name: 'Staging Promotion', status: 'success', duration: '35s' },
      { name: 'Canary Rollout (Prod)', status: 'success', duration: '21s' },
    ],
  },
  {
    id: 'pipe-ml-404',
    serviceId: 'ai-search-indexer',
    serviceName: 'ai-search-indexer',
    branch: 'fix/gpu-oom',
    commitHash: 'c903ef8',
    commitMessage: 'refactor: enable gradient checkpointing and batch 32 chunking',
    author: 'devin.vance@nexus.internal',
    status: 'running',
    duration: '1m 12s',
    startedAt: 'Just now',
    stages: [
      { name: 'Python Flake8 & Ruff', status: 'success', duration: '12s' },
      { name: 'PyTorch Model Verification', status: 'running', duration: '1m 00s' },
      { name: 'Container Build', status: 'queued', duration: '0s' },
      { name: 'GKE Deploy', status: 'queued', duration: '0s' },
    ],
  },
];

export const INITIAL_ACTIVITIES: ActivityEvent[] = [
  {
    id: 'act-01',
    timestamp: '18m ago',
    actor: 'Elena Rostova',
    action: 'Deployed v2.9.4 release via ArgoCD',
    target: 'auth-gateway',
    type: 'deploy',
  },
  {
    id: 'act-02',
    timestamp: '45m ago',
    actor: 'Platform Bot',
    action: 'Applied FinOps Right-Sizing recommendations on cluster nodes',
    target: 'aws-us-east-1-prod',
    type: 'cost_opt',
  },
  {
    id: 'act-03',
    timestamp: '2h ago',
    actor: 'Marcus Chen',
    action: 'Scaled replicas from 8 to 12 in response to traffic burst',
    target: 'checkout-orchestrator',
    type: 'scale',
  },
  {
    id: 'act-04',
    timestamp: '5h ago',
    actor: 'Devin Vance',
    action: 'Ran Terraform Plan in workspace ws-indexer-prod',
    target: 'ai-search-indexer',
    type: 'terraform',
  },
  {
    id: 'act-05',
    timestamp: '1d ago',
    actor: 'Sophia Lin',
    action: 'Provisioned new golden path service via Backstage template',
    target: 'customer-portal-web',
    type: 'provision',
  },
];
