import React, { useState } from 'react';
import { useIDP } from '../context/IDPContext';
import { GoldenPathTemplate } from '../types/idp';
import {
  Workflow,
  Plus,
  Clock,
  DollarSign,
  ShieldCheck,
  Code2,
  Cpu,
  Layers,
  CheckCircle2,
  ArrowRight,
} from 'lucide-react';

export const GoldenPathsView: React.FC = () => {
  const { templates, setIsProvisionModalOpen } = useIDP();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredTemplates = templates.filter((tpl) => {
    const matchesCat = selectedCategory === 'all' || tpl.category === selectedCategory;
    const matchesSearch =
      searchQuery === '' ||
      tpl.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tpl.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tpl.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Intro Header */}
      <div className="p-6 rounded-lg bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800">
        <div className="max-w-2xl">
          <div className="flex items-center gap-2 text-indigo-400 font-semibold text-xs uppercase tracking-wider">
            <Workflow className="h-4 w-4" />
            <span>Platform Engineering · Golden Paths</span>
          </div>
          <h2 className="mt-2 text-xl font-bold text-white tracking-tight">
            Self-Service Infrastructure & Software Templates
          </h2>
          <p className="mt-1.5 text-xs text-slate-300 leading-relaxed">
            Standardized, enterprise-compliant architecture patterns curated by the Platform Engineering team.
            Spin up production microservices with Terraform modules, Kubernetes manifests, CI/CD pipelines,
            and Datadog observability in under 3 minutes.
          </p>
        </div>

        <div className="mt-4 flex flex-wrap gap-4 pt-4 border-t border-slate-800/80 text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="h-4 w-4 text-emerald-400" />
            <span>Zero-Trust Security by Default</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Code2 className="h-4 w-4 text-indigo-400" />
            <span>GitOps ArgoCD Native</span>
          </div>
          <div className="flex items-center gap-1.5">
            <DollarSign className="h-4 w-4 text-amber-400" />
            <span>Automated Infracost Guardrails</span>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              selectedCategory === 'all'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Templates ({templates.length})
          </button>
          <button
            onClick={() => setSelectedCategory('backend')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              selectedCategory === 'backend'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Backend & Microservices
          </button>
          <button
            onClick={() => setSelectedCategory('frontend')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              selectedCategory === 'frontend'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Web Frontends
          </button>
          <button
            onClick={() => setSelectedCategory('data')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              selectedCategory === 'data'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Event & Data
          </button>
          <button
            onClick={() => setSelectedCategory('infra')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              selectedCategory === 'infra'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Cloud Infra
          </button>
        </div>

        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Filter templates..."
          className="h-8 px-3 text-xs bg-slate-900 border border-slate-800 rounded-md text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 sm:w-64"
        />
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredTemplates.map((template) => (
          <div
            key={template.id}
            className="p-5 rounded-lg bg-slate-900/60 border border-slate-800 hover:border-slate-700 hover:bg-slate-900 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-sm font-bold text-white">{template.title}</h3>
                  <div className="mt-1 flex items-center gap-2 text-xs text-slate-500">
                    <span>{template.author}</span>
                    <span aria-hidden="true">·</span>
                    <span className="flex items-center gap-1 font-mono">
                      <Clock className="h-3 w-3" />
                      {template.timeToDeploy}
                    </span>
                  </div>
                </div>

                <div className="text-right font-mono text-xs">
                  <span className="text-slate-400">Est. </span>
                  <span className="font-semibold text-emerald-400">
                    ${template.estimatedMonthlyCost}/mo
                  </span>
                </div>
              </div>

              <p className="mt-3 text-xs text-slate-400 leading-relaxed">
                {template.description}
              </p>

              {/* Technologies / Capabilities (Zero-Pill formatting) */}
              <div className="mt-4 flex flex-wrap items-center gap-2 text-[11px] text-slate-500 font-mono">
                {template.tags.map((tag, idx) => (
                  <React.Fragment key={tag}>
                    {idx > 0 && <span aria-hidden="true">·</span>}
                    <span className="text-slate-400">{tag}</span>
                  </React.Fragment>
                ))}
              </div>
            </div>

            <div className="mt-5 pt-3.5 border-t border-slate-800 flex items-center justify-between">
              <span className="text-[11px] font-mono text-slate-500">
                Cloud Support: {template.cloudSupport.map((c) => c.toUpperCase()).join(' · ')}
              </span>

              <button
                onClick={() => setIsProvisionModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-md transition-colors"
              >
                <span>Choose Template</span>
                <ArrowRight className="h-3 w-3" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
