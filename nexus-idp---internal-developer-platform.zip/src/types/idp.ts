export type ServiceTier = 'tier-1' | 'tier-2' | 'tier-3';
export type ServiceLifecycle = 'production' | 'staging' | 'experimental' | 'deprecated';
export type CloudProvider = 'aws' | 'gcp' | 'azure';
export type EntityKind = 'service' | 'website' | 'library' | 'pipeline' | 'database';

export interface ServiceEntity {
  id: string;
  name: string;
  displayName: string;
  description: string;
  kind: EntityKind;
  system: string;
  domain: string;
  ownerTeam: string;
  tier: ServiceTier;
  lifecycle: ServiceLifecycle;
  language: 'go' | 'typescript' | 'python' | 'rust' | 'java';
  repoUrl: string;
  docsUrl: string;
  openApiSpec?: string;
  healthStatus: 'healthy' | 'warning' | 'degraded' | 'outage';
  tags: string[];
  lastDeployedAt: string;
  costMonthly: number;
  costTrendPercent: number;
  cluster: string;
  namespace: string;
  replicas: {
    current: number;
    target: number;
    min: number;
    max: number;
  };
  resources: {
    cpuUsage: string;
    cpuRequest: string;
    cpuLimit: string;
    memoryUsage: string;
    memoryRequest: string;
    memoryLimit: string;
  };
  dependsOn: string[];
  consumedBy: string[];
  providesApis: string[];
  gitopsSyncStatus: 'synced' | 'outofsync' | 'progressing' | 'degraded';
  terraformWorkspaceId: string;
  ciPipelineId: string;
}

export interface TemplateField {
  id: string;
  label: string;
  description: string;
  type: 'text' | 'select' | 'boolean' | 'number';
  defaultValue: any;
  options?: { label: string; value: string }[];
  required?: boolean;
}

export interface SecurityPolicyCheck {
  name: string;
  tool: 'Trivy' | 'OPA Gatekeeper' | 'Checkov' | 'FinOps Guardrail';
  status: 'pass' | 'warn' | 'fail';
  description: string;
  remediation?: string;
}

export interface GoldenPathTemplate {
  id: string;
  title: string;
  description: string;
  category: 'backend' | 'frontend' | 'data' | 'infra' | 'ml';
  tags: string[];
  author: string;
  timeToDeploy: string;
  cloudSupport: CloudProvider[];
  estimatedMonthlyCost: number;
  fields: TemplateField[];
  terraformFiles: { filename: string; content: string }[];
  k8sFiles: { filename: string; content: string }[];
  cicdFiles: { filename: string; content: string }[];
  securityPolicies: SecurityPolicyCheck[];
}

export interface ProvisioningStep {
  id: string;
  name: string;
  description: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  durationSeconds?: number;
}

export interface ProvisioningJob {
  id: string;
  templateId: string;
  templateTitle: string;
  serviceName: string;
  displayName: string;
  ownerTeam: string;
  environment: 'production' | 'staging' | 'development';
  cloudProvider: CloudProvider;
  region: string;
  status: 'planning' | 'security_eval' | 'in_progress' | 'completed' | 'failed';
  startedAt: string;
  completedAt?: string;
  currentStepIndex: number;
  steps: ProvisioningStep[];
  tfPlanDiff: string;
  infracostDiff: {
    previousCostMonthly: number;
    newCostMonthly: number;
    deltaMonthly: number;
    breakdown: { resource: string; cost: number; change: string }[];
  };
  outputs: Record<string, string>;
  logs: { timestamp: string; level: 'info' | 'warn' | 'error' | 'success'; message: string }[];
}

export interface K8sPod {
  name: string;
  namespace: string;
  status: 'Running' | 'Pending' | 'CrashLoopBackOff' | 'Completed';
  restarts: number;
  age: string;
  cpuUsage: string;
  memUsage: string;
  ip: string;
  node: string;
  logs: string[];
}

export interface K8sCluster {
  id: string;
  name: string;
  provider: 'aws-eks' | 'gcp-gke' | 'azure-aks';
  region: string;
  version: string;
  nodeCount: number;
  cpuAllocatedPercent: number;
  memAllocatedPercent: number;
  status: 'healthy' | 'warning' | 'degraded';
  namespaces: string[];
  monthlyCost: number;
}

export interface TerraformWorkspace {
  id: string;
  name: string;
  environment: 'production' | 'staging' | 'dev';
  stateVersion: string;
  lastRunId: string;
  lastRunTime: string;
  driftDetected: boolean;
  resourcesCount: number;
  monthlyCost: number;
  planPending: boolean;
  repoPath: string;
  lockStatus: 'locked' | 'unlocked';
  managedResources: { type: string; name: string; status: string; id: string }[];
  planDiff: string;
}

export interface CostRecommendation {
  id: string;
  serviceId: string;
  serviceName: string;
  title: string;
  description: string;
  potentialSavingsMonthly: number;
  type: 'downsize_cpu' | 'idle_resource' | 'unattached_volume' | 'spot_migration';
  difficulty: 'easy' | 'moderate' | 'manual';
  status: 'available' | 'applied' | 'dismissed';
}

export interface PipelineStage {
  name: string;
  status: 'success' | 'running' | 'failed' | 'queued' | 'skipped';
  duration: string;
}

export interface PipelineRun {
  id: string;
  serviceId: string;
  serviceName: string;
  branch: string;
  commitHash: string;
  commitMessage: string;
  author: string;
  status: 'success' | 'running' | 'failed' | 'queued';
  duration: string;
  startedAt: string;
  stages: PipelineStage[];
}

export interface ActivityEvent {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  target: string;
  type: 'provision' | 'deploy' | 'scale' | 'terraform' | 'cost_opt';
}
