import React, { useState } from 'react';
import { useIDP } from '../context/IDPContext';
import {
  Server,
  Cpu,
  HardDrive,
  RefreshCw,
  Terminal,
  Activity,
  Layers,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw,
} from 'lucide-react';

export const KubernetesView: React.FC = () => {
  const {
    clusters,
    selectedClusterId,
    setSelectedClusterId,
    pods,
    restartPod,
    services,
    scaleServiceReplicas,
  } = useIDP();

  const [selectedNamespace, setSelectedNamespace] = useState<string>('all');
  const [podSearch, setPodSearch] = useState<string>('');
  const [activeLogPod, setActiveLogPod] = useState<string>(pods[0]?.name || '');
  const [logFilter, setLogFilter] = useState<'all' | 'error' | 'warn'>('all');
  const [scalingServiceId, setScalingServiceId] = useState<string | null>(null);
  const [scaleCount, setScaleCount] = useState<number>(3);

  const activeCluster = clusters.find((c) => c.id === selectedClusterId) || clusters[0];

  // Pods in this cluster/namespace
  const filteredPods = pods.filter((p) => {
    const matchesNs = selectedNamespace === 'all' || p.namespace === selectedNamespace;
    const matchesSearch =
      podSearch === '' ||
      p.name.toLowerCase().includes(podSearch.toLowerCase()) ||
      p.node.toLowerCase().includes(podSearch.toLowerCase()) ||
      p.ip.includes(podSearch);
    return matchesNs && matchesSearch;
  });

  const currentPod = pods.find((p) => p.name === activeLogPod) || pods[0];

  const filteredLogs = currentPod?.logs.filter((l) => {
    if (logFilter === 'error') return l.includes('[ERROR]') || l.includes('[FATAL]');
    if (logFilter === 'warn') return l.includes('[WARN]') || l.includes('[ERROR]');
    return true;
  }) || [];

  return (
    <div className="space-y-6">
      {/* Cluster Overview Ribbon */}
      <div className="p-5 rounded-lg bg-slate-900/60 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
              <Server className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">{activeCluster.name}</h2>
                <span className="font-mono text-xs text-indigo-400">({activeCluster.region})</span>
              </div>
              <div className="mt-0.5 flex items-center gap-2 text-xs text-slate-400 font-mono">
                <span>{activeCluster.version}</span>
                <span aria-hidden="true">·</span>
                <span>{activeCluster.nodeCount} worker nodes</span>
                <span aria-hidden="true">·</span>
                <span>${activeCluster.monthlyCost.toLocaleString()}/mo</span>
              </div>
            </div>
          </div>

          {/* Cluster Switcher */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Cluster:</span>
            <select
              value={selectedClusterId}
              onChange={(e) => setSelectedClusterId(e.target.value)}
              className="h-8 px-3 text-xs bg-slate-950 border border-slate-800 text-white font-mono rounded-md focus:outline-none focus:border-indigo-500"
            >
              {clusters.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} · {c.region} ({c.provider})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Node Capacity Allocation Bars */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-slate-800/80">
          <div>
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="text-slate-400 flex items-center gap-1.5">
                <Cpu className="h-3.5 w-3.5 text-indigo-400" />
                Cluster CPU Request Allocation
              </span>
              <span className="font-mono font-semibold text-slate-200 tabular-nums">
                {activeCluster.cpuAllocatedPercent}%
              </span>
            </div>
            <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
              <div
                className={`h-full transition-all duration-500 ${
                  activeCluster.cpuAllocatedPercent > 80 ? 'bg-amber-500' : 'bg-indigo-500'
                }`}
                style={{ width: `${activeCluster.cpuAllocatedPercent}%` }}
              ></div>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="text-slate-400 flex items-center gap-1.5">
                <HardDrive className="h-3.5 w-3.5 text-indigo-400" />
                Cluster Memory Allocation
              </span>
              <span className="font-mono font-semibold text-slate-200 tabular-nums">
                {activeCluster.memAllocatedPercent}%
              </span>
            </div>
            <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
              <div
                className={`h-full transition-all duration-500 ${
                  activeCluster.memAllocatedPercent > 80 ? 'bg-amber-500' : 'bg-indigo-500'
                }`}
                style={{ width: `${activeCluster.memAllocatedPercent}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Pods Controller & Filters */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Namespace:</span>
          <select
            value={selectedNamespace}
            onChange={(e) => setSelectedNamespace(e.target.value)}
            className="h-8 px-2.5 text-xs bg-slate-900 border border-slate-800 text-white font-mono rounded-md focus:outline-none"
          >
            <option value="all">All Namespaces ({activeCluster.namespaces.length})</option>
            {activeCluster.namespaces.map((ns) => (
              <option key={ns} value={ns}>
                {ns}
              </option>
            ))}
          </select>
        </div>

        <div className="relative sm:w-64">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-500" />
          <input
            type="text"
            value={podSearch}
            onChange={(e) => setPodSearch(e.target.value)}
            placeholder="Search pods, IP, node..."
            className="w-full h-8 pl-8 pr-3 text-xs bg-slate-900 border border-slate-800 rounded-md text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-mono"
          />
        </div>
      </div>

      {/* Pods Table & Live Log Inspector Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Pods List (7 cols) */}
        <div className="lg:col-span-7 space-y-3">
          <span className="text-xs font-semibold text-slate-300">
            Active Pods ({filteredPods.length})
          </span>
          <div className="overflow-x-auto rounded-lg border border-slate-800 bg-slate-950">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="bg-slate-900/80 border-b border-slate-800 text-[11px] text-slate-400">
                  <th className="py-2.5 px-3">Pod Instance</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Restarts</th>
                  <th className="py-2.5 px-3">Usage</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850">
                {filteredPods.map((pod) => (
                  <tr
                    key={pod.name}
                    onClick={() => setActiveLogPod(pod.name)}
                    className={`cursor-pointer transition-colors ${
                      activeLogPod === pod.name ? 'bg-indigo-950/40' : 'hover:bg-slate-900/50'
                    }`}
                  >
                    <td className="py-2.5 px-3">
                      <div className="font-semibold text-slate-200 truncate max-w-xs">
                        {pod.name}
                      </div>
                      <div className="text-[10px] text-slate-500">ns: {pod.namespace}</div>
                    </td>
                    <td className="py-2.5 px-3">
                      {pod.status === 'Running' ? (
                        <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
                          Running
                        </span>
                      ) : (
                        <span className="text-rose-400 flex items-center gap-1 font-semibold">
                          <span className="h-1.5 w-1.5 rounded-full bg-rose-500"></span>
                          {pod.status}
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-slate-400 tabular-nums">
                      {pod.restarts}
                    </td>
                    <td className="py-2.5 px-3 text-slate-400 text-[11px]">
                      {pod.cpuUsage} · {pod.memUsage}
                    </td>
                    <td className="py-2.5 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => restartPod(pod.name)}
                        title="Dispatch graceful container restart"
                        className="px-2 py-1 text-[11px] text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors"
                      >
                        Restart
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Live Terminal Log Streamer (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-300">
              Terminal: <span className="font-mono text-indigo-400 truncate">{currentPod?.name}</span>
            </span>

            {/* Log filter buttons */}
            <div className="flex items-center gap-1 p-0.5 bg-slate-900 border border-slate-800 rounded text-[10px] font-mono">
              <button
                onClick={() => setLogFilter('all')}
                className={`px-2 py-0.5 rounded ${
                  logFilter === 'all' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setLogFilter('warn')}
                className={`px-2 py-0.5 rounded ${
                  logFilter === 'warn' ? 'bg-slate-800 text-amber-300 font-bold' : 'text-slate-400'
                }`}
              >
                Warn
              </button>
              <button
                onClick={() => setLogFilter('error')}
                className={`px-2 py-0.5 rounded ${
                  logFilter === 'error' ? 'bg-slate-800 text-rose-400 font-bold' : 'text-slate-400'
                }`}
              >
                Errors
              </button>
            </div>
          </div>

          <div className="p-3.5 rounded-lg bg-black border border-slate-800 font-mono text-xs text-slate-300 h-96 overflow-y-auto space-y-1.5 leading-relaxed">
            {filteredLogs.length > 0 ? (
              filteredLogs.map((log, idx) => (
                <div
                  key={idx}
                  className={`${
                    log.includes('[ERROR]') || log.includes('[FATAL]')
                      ? 'text-rose-400 font-semibold'
                      : log.includes('[WARN]')
                      ? 'text-amber-300'
                      : 'text-slate-300'
                  }`}
                >
                  {log}
                </div>
              ))
            ) : (
              <div className="text-slate-600">No logs matching filter criteria.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
