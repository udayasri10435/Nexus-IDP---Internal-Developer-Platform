import React, { useState } from 'react';
import { useIDP } from '../context/IDPContext';
import {
  DollarSign,
  TrendingDown,
  TrendingUp,
  Cpu,
  Layers,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Sliders,
  Sparkles,
} from 'lucide-react';

export const FinOpsCostView: React.FC = () => {
  const { services, costRecommendations, applyCostRecommendation } = useIDP();

  const totalMonthlySpend = services.reduce((acc, s) => acc + s.costMonthly, 0);
  const monthlyBudget = 12000;
  const budgetPercent = Math.min(100, Math.round((totalMonthlySpend / monthlyBudget) * 100));

  // Team breakdown
  const teamSpend = services.reduce((acc, s) => {
    acc[s.ownerTeam] = (acc[s.ownerTeam] || 0) + s.costMonthly;
    return acc;
  }, {} as Record<string, number>);

  // Interactive Infracost simulator
  const [simReplicas, setSimReplicas] = useState<number>(3);
  const [simCpu, setSimCpu] = useState<number>(2);
  const simCost = simReplicas * (simCpu * 35) + 40;

  return (
    <div className="space-y-6">
      {/* Intro Header */}
      <div className="p-5 rounded-lg bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white">FinOps & Cloud Cost Visibility</h2>
            <span className="font-mono text-xs text-emerald-400 font-semibold">Infracost Engine</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Real-time infrastructure cost tracking, budget guardrails, and automated right-sizing recommendations.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-[11px] text-slate-400">Monthly Run Rate</div>
            <div className="text-xl font-bold font-mono text-white tabular-nums">
              ${totalMonthlySpend.toLocaleString()}/mo
            </div>
          </div>
        </div>
      </div>

      {/* Budget & Provider Allocation Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Budget Progress Card */}
        <div className="p-4 rounded-lg bg-slate-900/40 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Quarterly Cloud Budget</span>
            <span className="font-mono font-bold text-white tabular-nums">
              ${totalMonthlySpend.toLocaleString()} / ${monthlyBudget.toLocaleString()}
            </span>
          </div>
          <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
            <div
              className={`h-full transition-all duration-500 ${
                budgetPercent > 90 ? 'bg-rose-500' : budgetPercent > 75 ? 'bg-amber-500' : 'bg-indigo-500'
              }`}
              style={{ width: `${budgetPercent}%` }}
            ></div>
          </div>
          <span className="text-[11px] text-slate-500 font-mono block">
            {budgetPercent}% of monthly ceiling utilized ({100 - budgetPercent}% buffer remaining)
          </span>
        </div>

        {/* Cloud Provider Share */}
        <div className="p-4 rounded-lg bg-slate-900/40 border border-slate-800 space-y-2">
          <span className="text-xs text-slate-400">Cloud Provider Substrates</span>
          <div className="space-y-1.5 pt-1 text-xs font-mono">
            <div className="flex items-center justify-between">
              <span className="text-slate-300">AWS (EKS & Aurora)</span>
              <span className="text-white font-semibold">74%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-300">GCP (GKE & AI GPU)</span>
              <span className="text-white font-semibold">22%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-300">Cloudflare & Edge</span>
              <span className="text-white font-semibold">4%</span>
            </div>
          </div>
        </div>

        {/* Total Optimization Potential */}
        <div className="p-4 rounded-lg bg-emerald-950/20 border border-emerald-900/50 space-y-2">
          <span className="text-xs text-emerald-400 font-semibold">
            Actionable Right-Sizing Savings
          </span>
          <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
            $
            {costRecommendations
              .filter((r) => r.status === 'available')
              .reduce((acc, r) => acc + r.potentialSavingsMonthly, 0)
              .toLocaleString()}
            <span className="text-xs font-normal text-emerald-500">/month</span>
          </div>
          <span className="text-[11px] text-slate-400 block leading-relaxed">
            Apply recommendations below to eliminate unreserved idle CPU requests and unused storage.
          </span>
        </div>
      </div>

      {/* Actionable Right-Sizing Recommendations List */}
      <div className="space-y-3">
        <span className="text-xs font-semibold text-slate-300">
          Automated Cost Recommendations ({costRecommendations.filter((r) => r.status === 'available').length})
        </span>

        {costRecommendations.map((rec) => (
          <div
            key={rec.id}
            className={`p-4 rounded-lg border transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4 ${
              rec.status === 'applied'
                ? 'bg-slate-900/30 border-slate-800 opacity-60'
                : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-white">{rec.title}</span>
                <span className="text-xs font-mono text-indigo-400">({rec.serviceName})</span>
                <span className="font-mono text-xs text-emerald-400 font-bold tabular-nums">
                  Save ${rec.potentialSavingsMonthly}/mo
                </span>
              </div>
              <p className="mt-1 text-xs text-slate-400 max-w-2xl leading-relaxed">
                {rec.description}
              </p>
            </div>

            <div className="shrink-0">
              {rec.status === 'applied' ? (
                <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono font-semibold">
                  <CheckCircle2 className="h-4 w-4" />
                  Applied (Savings Active)
                </span>
              ) : (
                <button
                  onClick={() => applyCostRecommendation(rec.id)}
                  className="px-3.5 py-1.5 text-xs font-semibold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors"
                >
                  Apply Right-Sizing
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Interactive Infracost Cost Estimator Sandbox */}
      <div className="p-5 rounded-lg bg-slate-900/60 border border-slate-800 space-y-4">
        <div>
          <h3 className="text-sm font-bold text-white">Interactive Infracost Sizing Simulator</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Test resource scaling adjustments and compute prospective cloud cost deltas in real time.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-2">
          <div>
            <label className="text-xs font-semibold text-slate-300">
              Workload Pod Replicas: <span className="font-mono text-indigo-400">{simReplicas}</span>
            </label>
            <input
              type="range"
              min={1}
              max={16}
              value={simReplicas}
              onChange={(e) => setSimReplicas(Number(e.target.value))}
              className="mt-2 w-full accent-indigo-500 cursor-pointer"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300">
              CPU Request per Pod: <span className="font-mono text-indigo-400">{simCpu} Cores</span>
            </label>
            <input
              type="range"
              min={1}
              max={8}
              value={simCpu}
              onChange={(e) => setSimCpu(Number(e.target.value))}
              className="mt-2 w-full accent-indigo-500 cursor-pointer"
            />
          </div>

          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between font-mono">
            <div>
              <span className="text-[11px] text-slate-400 block">Projected Monthly Bill</span>
              <span className="text-lg font-bold text-white tabular-nums">${simCost}/mo</span>
            </div>
            <span className="text-[11px] text-emerald-400">Infracost Verified</span>
          </div>
        </div>
      </div>

      {/* Squad / Team Cost Distribution */}
      <div>
        <span className="text-xs font-semibold text-slate-300">Spend by Engineering Squad</span>
        <div className="mt-2 divide-y divide-slate-850 rounded-lg border border-slate-800 bg-slate-950 text-xs font-mono">
          {Object.entries(teamSpend).map(([team, amount]) => (
            <div key={team} className="py-2.5 px-4 flex items-center justify-between">
              <span className="text-slate-200">{team}</span>
              <div className="flex items-center gap-4">
                <span className="text-slate-400">
                  {Math.round((amount / (totalMonthlySpend || 1)) * 100)}%
                </span>
                <span className="font-bold text-white tabular-nums">
                  ${amount.toLocaleString()}/mo
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
