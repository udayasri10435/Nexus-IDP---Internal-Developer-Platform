import React from 'react';
import { useIDP } from '../context/IDPContext';
import {
  Boxes,
  Plus,
  Search,
  Server,
  Terminal,
  Layers,
  GitBranch,
  DollarSign,
  Workflow,
  ChevronDown,
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    setIsProvisionModalOpen,
    selectedClusterId,
    setSelectedClusterId,
    clusters,
    searchQuery,
    setSearchQuery,
    services,
  } = useIDP();

  const totalCost = services.reduce((acc, s) => acc + s.costMonthly, 0);

  return (
    <header className="sticky top-0 z-30 border-b border-slate-800 bg-slate-950/95 backdrop-blur-md">
      {/* Primary Top Bar Contract: Zone 1 (Brand) - Zone 2 (Navigation) - Zone 3 (Actions) */}
      <div className="flex h-14 items-center justify-between px-4 sm:px-6">
        {/* Zone 1: Single text element Brand Title */}
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-600/30">
            <Boxes className="h-4 w-4" />
          </div>
          <span className="text-base font-bold tracking-tight text-white">
            Nexus <span className="font-medium text-slate-400">IDP</span>
          </span>
          <span className="hidden lg:inline text-xs text-slate-500 font-mono">
            v2.8 · platform-prod
          </span>
        </div>

        {/* Zone 2: Navigation Links (Clean text links & functional tab buttons) */}
        <nav className="hidden md:flex items-center gap-1 text-xs font-medium">
          <button
            onClick={() => setActiveTab('catalog')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'catalog'
                ? 'bg-slate-800 text-white font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Layers className="h-3.5 w-3.5" />
            <span>Service Catalog</span>
          </button>

          <button
            onClick={() => setActiveTab('provisioner')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'provisioner'
                ? 'bg-slate-800 text-white font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Workflow className="h-3.5 w-3.5" />
            <span>Golden Paths</span>
          </button>

          <button
            onClick={() => setActiveTab('kubernetes')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'kubernetes'
                ? 'bg-slate-800 text-white font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Server className="h-3.5 w-3.5" />
            <span>Kubernetes</span>
          </button>

          <button
            onClick={() => setActiveTab('terraform')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'terraform'
                ? 'bg-slate-800 text-white font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Terminal className="h-3.5 w-3.5" />
            <span>Terraform IaC</span>
          </button>

          <button
            onClick={() => setActiveTab('cicd')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'cicd'
                ? 'bg-slate-800 text-white font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <GitBranch className="h-3.5 w-3.5" />
            <span>GitOps CI/CD</span>
          </button>

          <button
            onClick={() => setActiveTab('finops')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'finops'
                ? 'bg-slate-800 text-white font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <DollarSign className="h-3.5 w-3.5" />
            <span>FinOps</span>
            <span className="font-mono text-[10px] text-emerald-400 tabular-nums">
              ${totalCost.toLocaleString()}/mo
            </span>
          </button>
        </nav>

        {/* Zone 3: Primary Actions & Utilities */}
        <div className="flex items-center gap-2.5">
          {/* Quick Search */}
          <div className="relative hidden xl:block w-48">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search catalog... (⌘K)"
              className="w-full h-8 pl-8 pr-3 text-xs bg-slate-900 border border-slate-800 rounded-md text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
            />
          </div>

          {/* Cluster Switcher */}
          <div className="relative hidden sm:flex items-center">
            <select
              value={selectedClusterId}
              onChange={(e) => setSelectedClusterId(e.target.value)}
              className="h-8 pl-2.5 pr-7 text-xs bg-slate-900 border border-slate-800 text-slate-300 rounded-md font-mono appearance-none cursor-pointer hover:bg-slate-850 focus:outline-none focus:border-slate-700"
            >
              {clusters.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.region})
                </option>
              ))}
            </select>
            <ChevronDown className="pointer-events-none absolute right-2 h-3 w-3 text-slate-500" />
          </div>

          {/* Golden Path Provision CTA Button */}
          <button
            onClick={() => setIsProvisionModalOpen(true)}
            className="flex items-center gap-1.5 h-8 px-3 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-md shadow-sm shadow-indigo-600/30 transition-colors whitespace-nowrap"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Provision Service</span>
          </button>
        </div>
      </div>

      {/* Mobile Nav strip for small viewports */}
      <div className="flex md:hidden overflow-x-auto px-4 py-2 border-t border-slate-850 gap-2 text-xs">
        <button
          onClick={() => setActiveTab('catalog')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeTab === 'catalog' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Catalog
        </button>
        <button
          onClick={() => setActiveTab('provisioner')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeTab === 'provisioner' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Golden Paths
        </button>
        <button
          onClick={() => setActiveTab('kubernetes')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeTab === 'kubernetes' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Kubernetes
        </button>
        <button
          onClick={() => setActiveTab('terraform')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeTab === 'terraform' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Terraform
        </button>
        <button
          onClick={() => setActiveTab('cicd')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeTab === 'cicd' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          CI/CD
        </button>
        <button
          onClick={() => setActiveTab('finops')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeTab === 'finops' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          FinOps
        </button>
      </div>
    </header>
  );
};
