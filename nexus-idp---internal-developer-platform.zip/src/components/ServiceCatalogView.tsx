import React, { useState, useMemo } from 'react';
import { useIDP } from '../context/IDPContext';
import { ServiceEntity, EntityKind, ServiceLifecycle } from '../types/idp';
import {
  Layers,
  Search,
  Filter,
  ArrowUpDown,
  ExternalLink,
  Cpu,
  GitBranch,
  RefreshCw,
  SlidersHorizontal,
  ChevronRight,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';

export const ServiceCatalogView: React.FC = () => {
  const {
    services,
    setSelectedService,
    setIsProvisionModalOpen,
    searchQuery,
    setSearchQuery,
    triggerPipelineRun,
  } = useIDP();

  const [selectedKind, setSelectedKind] = useState<string>('all');
  const [selectedLifecycle, setSelectedLifecycle] = useState<string>('all');
  const [selectedTeam, setSelectedTeam] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');
  const [sortBy, setSortBy] = useState<'name' | 'cost' | 'replicas'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Available teams for filtering
  const teams = useMemo(() => {
    return Array.from(new Set(services.map((s) => s.ownerTeam))).sort();
  }, [services]);

  // Filtered & sorted services
  const filteredServices = useMemo(() => {
    return services
      .filter((s) => {
        const matchesSearch =
          searchQuery === '' ||
          s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.domain.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.ownerTeam.toLowerCase().includes(searchQuery.toLowerCase());

        const matchesKind = selectedKind === 'all' || s.kind === selectedKind;
        const matchesLifecycle = selectedLifecycle === 'all' || s.lifecycle === selectedLifecycle;
        const matchesTeam = selectedTeam === 'all' || s.ownerTeam === selectedTeam;

        return matchesSearch && matchesKind && matchesLifecycle && matchesTeam;
      })
      .sort((a, b) => {
        let comparison = 0;
        if (sortBy === 'name') {
          comparison = a.name.localeCompare(b.name);
        } else if (sortBy === 'cost') {
          comparison = a.costMonthly - b.costMonthly;
        } else if (sortBy === 'replicas') {
          comparison = a.replicas.current - b.replicas.current;
        }
        return sortOrder === 'asc' ? comparison : -comparison;
      });
  }, [services, searchQuery, selectedKind, selectedLifecycle, selectedTeam, sortBy, sortOrder]);

  const totalCost = services.reduce((acc, s) => acc + s.costMonthly, 0);
  const tier1Count = services.filter((s) => s.tier === 'tier-1').length;
  const syncedCount = services.filter((s) => s.gitopsSyncStatus === 'synced').length;
  const syncRate = Math.round((syncedCount / (services.length || 1)) * 100);

  return (
    <div className="space-y-6">
      {/* Top Banner / Platform Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 rounded-lg bg-slate-900/60 border border-slate-800">
        <div>
          <span className="text-xs text-slate-400">Total Registered Services</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-white">
              {services.length}
            </span>
            <span className="text-xs text-slate-500">
              Across {new Set(services.map((s) => s.cluster)).size} clusters
            </span>
          </div>
        </div>

        <div>
          <span className="text-xs text-slate-400">Tier-1 Critical Services</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-indigo-400">
              {tier1Count}
            </span>
            <span className="text-xs text-slate-500">Strict 99.99% SLO</span>
          </div>
        </div>

        <div>
          <span className="text-xs text-slate-400">GitOps Synchronization Rate</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-emerald-400">
              {syncRate}%
            </span>
            <span className="text-xs text-slate-500">ArgoCD verified</span>
          </div>
        </div>

        <div>
          <span className="text-xs text-slate-400">Monthly Catalog Compute Spend</span>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tabular-nums text-white">
              ${totalCost.toLocaleString()}
            </span>
            <span className="text-xs text-slate-500">AWS + GCP substrate</span>
          </div>
        </div>
      </div>

      {/* Control Strip & Interactive Filters */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
        {/* Segmented Kind Control */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg">
          <button
            onClick={() => setSelectedKind('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              selectedKind === 'all'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Entities ({services.length})
          </button>
          <button
            onClick={() => setSelectedKind('service')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              selectedKind === 'service'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Services ({services.filter((s) => s.kind === 'service').length})
          </button>
          <button
            onClick={() => setSelectedKind('pipeline')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              selectedKind === 'pipeline'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Pipelines ({services.filter((s) => s.kind === 'pipeline').length})
          </button>
          <button
            onClick={() => setSelectedKind('website')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              selectedKind === 'website'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Web Apps ({services.filter((s) => s.kind === 'website').length})
          </button>
        </div>

        {/* Secondary Filters & Search */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Search Input */}
          <div className="relative flex-1 sm:w-60">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter by name, domain..."
              className="w-full h-8 pl-8 pr-3 text-xs bg-slate-900 border border-slate-800 rounded-md text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Team Filter */}
          <select
            value={selectedTeam}
            onChange={(e) => setSelectedTeam(e.target.value)}
            className="h-8 px-2.5 text-xs bg-slate-900 border border-slate-800 text-slate-300 rounded-md focus:outline-none"
          >
            <option value="all">All Teams</option>
            {teams.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>

          {/* Lifecycle Filter */}
          <select
            value={selectedLifecycle}
            onChange={(e) => setSelectedLifecycle(e.target.value)}
            className="h-8 px-2.5 text-xs bg-slate-900 border border-slate-800 text-slate-300 rounded-md focus:outline-none"
          >
            <option value="all">All Lifecycles</option>
            <option value="production">Production</option>
            <option value="staging">Staging</option>
            <option value="experimental">Experimental</option>
          </select>

          {/* View Mode Toggle */}
          <div className="flex items-center border border-slate-800 rounded-md overflow-hidden bg-slate-900">
            <button
              onClick={() => setViewMode('table')}
              className={`px-2.5 py-1 text-xs transition-colors ${
                viewMode === 'table' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Table View"
            >
              List
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`px-2.5 py-1 text-xs transition-colors ${
                viewMode === 'grid' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Grid View"
            >
              Cards
            </button>
          </div>
        </div>
      </div>

      {/* Main Content: Table or Grid */}
      {filteredServices.length === 0 ? (
        <div className="py-16 text-center border border-dashed border-slate-800 rounded-lg">
          <Layers className="mx-auto h-8 w-8 text-slate-600" />
          <h3 className="mt-3 text-sm font-semibold text-slate-300">No matching services found</h3>
          <p className="mt-1 text-xs text-slate-500">
            Try adjusting your search criteria or register a new service with a Golden Path template.
          </p>
          <button
            onClick={() => setIsProvisionModalOpen(true)}
            className="mt-4 px-3.5 py-1.5 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-500 rounded-md transition-colors"
          >
            Provision Service
          </button>
        </div>
      ) : viewMode === 'table' ? (
        /* High-Density Data Grid */
        <div className="overflow-x-auto rounded-lg border border-slate-800 bg-slate-950">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/70 text-[11px] font-medium text-slate-400 tracking-wider">
                <th
                  onClick={() => {
                    if (sortBy === 'name') setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
                    else {
                      setSortBy('name');
                      setSortOrder('asc');
                    }
                  }}
                  className="py-3 px-4 cursor-pointer hover:text-white"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Service & Domain</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </th>
                <th className="py-3 px-4">Owner & Tier</th>
                <th className="py-3 px-4">Kubernetes Workload</th>
                <th className="py-3 px-4">GitOps & Health</th>
                <th
                  onClick={() => {
                    if (sortBy === 'cost') setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
                    else {
                      setSortBy('cost');
                      setSortOrder('asc');
                    }
                  }}
                  className="py-3 px-4 text-right cursor-pointer hover:text-white"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>Monthly Cost</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-850 text-xs">
              {filteredServices.map((svc) => (
                <tr
                  key={svc.id}
                  onClick={() => setSelectedService(svc)}
                  className="group hover:bg-slate-900/50 cursor-pointer transition-colors"
                >
                  {/* Name, Language, Domain (Zero-Pill formatting) */}
                  <td className="py-3.5 px-4">
                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-100 group-hover:text-indigo-400 transition-colors">
                          {svc.displayName}
                        </span>
                        <span className="text-[11px] font-mono text-slate-500">
                          {svc.name}
                        </span>
                      </div>
                      <div className="mt-1 flex items-center gap-1.5 text-[11px] text-slate-500">
                        <span className="capitalize">{svc.kind}</span>
                        <span aria-hidden="true">·</span>
                        <span>{svc.domain}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono uppercase">{svc.language}</span>
                      </div>
                    </div>
                  </td>

                  {/* Owner & Tier */}
                  <td className="py-3.5 px-4">
                    <div className="text-slate-300 font-medium">{svc.ownerTeam}</div>
                    <div className="mt-0.5 text-[11px] text-slate-500 flex items-center gap-1.5">
                      <span className="font-mono uppercase">{svc.tier}</span>
                      <span aria-hidden="true">·</span>
                      <span className="capitalize">{svc.lifecycle}</span>
                    </div>
                  </td>

                  {/* K8s Workload Details */}
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2">
                      <span className="font-mono tabular-nums font-semibold text-slate-200">
                        {svc.replicas.current} / {svc.replicas.target} pods
                      </span>
                      <span className="text-[11px] font-mono text-slate-500">
                        ({svc.resources.cpuUsage} CPU)
                      </span>
                    </div>
                    <div className="mt-0.5 text-[11px] font-mono text-slate-500">
                      ns: {svc.namespace} · {svc.cluster}
                    </div>
                  </td>

                  {/* GitOps & Health Status */}
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2">
                      {svc.healthStatus === 'healthy' && (
                        <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
                          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
                          Healthy
                        </span>
                      )}
                      {svc.healthStatus === 'warning' && (
                        <span className="flex items-center gap-1.5 text-amber-400 font-medium">
                          <span className="h-1.5 w-1.5 rounded-full bg-amber-500"></span>
                          Warning
                        </span>
                      )}
                      {svc.healthStatus === 'degraded' && (
                        <span className="flex items-center gap-1.5 text-rose-400 font-medium">
                          <span className="h-1.5 w-1.5 rounded-full bg-rose-500"></span>
                          Degraded
                        </span>
                      )}
                      <span className="text-slate-600">/</span>
                      <span className="text-slate-400 capitalize">{svc.gitopsSyncStatus}</span>
                    </div>
                    <div className="mt-0.5 text-[11px] text-slate-500">
                      Deployed {svc.lastDeployedAt}
                    </div>
                  </td>

                  {/* Cost & FinOps */}
                  <td className="py-3.5 px-4 text-right">
                    <div className="font-mono tabular-nums font-semibold text-slate-200">
                      ${svc.costMonthly.toLocaleString()}
                      <span className="text-slate-500 font-normal text-[11px]">/mo</span>
                    </div>
                    <div className="mt-0.5 flex items-center justify-end gap-1 text-[11px]">
                      {svc.costTrendPercent <= 0 ? (
                        <span className="text-emerald-400 flex items-center gap-0.5 font-mono">
                          <TrendingDown className="h-3 w-3" />
                          {Math.abs(svc.costTrendPercent)}%
                        </span>
                      ) : (
                        <span className="text-amber-400 flex items-center gap-0.5 font-mono">
                          <TrendingUp className="h-3 w-3" />
                          +{svc.costTrendPercent}%
                        </span>
                      )}
                    </div>
                  </td>

                  {/* Quick Action Button */}
                  <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => triggerPipelineRun(svc.id)}
                        title="Trigger CI/CD GitOps Deploy"
                        className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors"
                      >
                        <RefreshCw className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => setSelectedService(svc)}
                        className="px-2.5 py-1 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors"
                      >
                        Inspect
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        /* Card Grid Mode */
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredServices.map((svc) => (
            <div
              key={svc.id}
              onClick={() => setSelectedService(svc)}
              className="p-4 rounded-lg bg-slate-900/60 border border-slate-800 hover:border-slate-700 hover:bg-slate-900 transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                {/* Header: Title and Health */}
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-semibold text-slate-100 group-hover:text-indigo-400 transition-colors">
                      {svc.displayName}
                    </h3>
                    <span className="text-[11px] font-mono text-slate-500">{svc.name}</span>
                  </div>
                  {svc.healthStatus === 'healthy' ? (
                    <span className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-medium">
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
                      Healthy
                    </span>
                  ) : svc.healthStatus === 'warning' ? (
                    <span className="flex items-center gap-1.5 text-[11px] text-amber-400 font-medium">
                      <span className="h-1.5 w-1.5 rounded-full bg-amber-500"></span>
                      Warning
                    </span>
                  ) : (
                    <span className="flex items-center gap-1.5 text-[11px] text-rose-400 font-medium">
                      <span className="h-1.5 w-1.5 rounded-full bg-rose-500"></span>
                      Degraded
                    </span>
                  )}
                </div>

                <p className="mt-2 text-xs text-slate-400 line-clamp-2 leading-relaxed">
                  {svc.description}
                </p>

                {/* Metadata strip (No pills) */}
                <div className="mt-3 flex items-center gap-2 text-[11px] text-slate-500">
                  <span>{svc.ownerTeam}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono uppercase">{svc.tier}</span>
                  <span aria-hidden="true">·</span>
                  <span>{svc.domain}</span>
                </div>
              </div>

              {/* Bottom Metrics Bar */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                <div className="text-slate-400">
                  <span className="tabular-nums font-semibold text-slate-200">
                    {svc.replicas.current}
                  </span>{' '}
                  replicas
                </div>
                <div className="tabular-nums text-slate-200 font-semibold">
                  ${svc.costMonthly.toLocaleString()}/mo
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
