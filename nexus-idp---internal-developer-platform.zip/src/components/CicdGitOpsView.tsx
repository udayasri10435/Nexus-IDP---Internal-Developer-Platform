import React, { useState } from 'react';
import { useIDP } from '../context/IDPContext';
import {
  GitBranch,
  Play,
  CheckCircle2,
  RefreshCw,
  Clock,
  ExternalLink,
  Layers,
  ShieldCheck,
  Check,
} from 'lucide-react';

export const CicdGitOpsView: React.FC = () => {
  const { pipelines, services, triggerPipelineRun } = useIDP();
  const [selectedServiceToDeploy, setSelectedServiceToDeploy] = useState<string>(services[0]?.id || '');

  return (
    <div className="space-y-6">
      {/* Intro Header */}
      <div className="p-5 rounded-lg bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white">GitOps & Continuous Delivery (ArgoCD)</h2>
            <span className="font-mono text-xs text-indigo-400">GitHub Actions + ArgoCD</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Declarative Kubernetes GitOps synchronizations with automated canary rollouts and instant rollback.
          </p>
        </div>

        {/* Trigger deployment */}
        <div className="flex items-center gap-2">
          <select
            value={selectedServiceToDeploy}
            onChange={(e) => setSelectedServiceToDeploy(e.target.value)}
            className="h-8 px-2.5 text-xs bg-slate-950 border border-slate-800 text-white font-mono rounded-md focus:outline-none"
          >
            {services.map((s) => (
              <option key={s.id} value={s.id}>
                {s.displayName} ({s.name})
              </option>
            ))}
          </select>
          <button
            onClick={() => triggerPipelineRun(selectedServiceToDeploy)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-md transition-colors whitespace-nowrap"
          >
            <Play className="h-3 w-3" />
            <span>Deploy</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-lg bg-slate-900/40 border border-slate-800">
          <span className="text-xs text-slate-400">Total Deployment Runs</span>
          <div className="mt-1 text-2xl font-bold font-mono text-white tabular-nums">
            {pipelines.length}
          </div>
          <span className="text-[11px] text-slate-500">Across all environments</span>
        </div>

        <div className="p-4 rounded-lg bg-slate-900/40 border border-slate-800">
          <span className="text-xs text-slate-400">ArgoCD Sync Success Rate</span>
          <div className="mt-1 text-2xl font-bold font-mono text-emerald-400 tabular-nums">
            99.2%
          </div>
          <span className="text-[11px] text-slate-500">Zero deployment rollbacks this week</span>
        </div>

        <div className="p-4 rounded-lg bg-slate-900/40 border border-slate-800">
          <span className="text-xs text-slate-400">Mean Lead Time to Production</span>
          <div className="mt-1 text-2xl font-bold font-mono text-indigo-400 tabular-nums">
            3m 12s
          </div>
          <span className="text-[11px] text-slate-500">From git commit to live ingress</span>
        </div>
      </div>

      {/* Pipelines List */}
      <div className="space-y-3">
        <span className="text-xs font-semibold text-slate-300">Deployment Pipeline History</span>
        {pipelines.map((run) => (
          <div
            key={run.id}
            className="p-4 rounded-lg bg-slate-900/60 border border-slate-800 space-y-3"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-white">{run.serviceName}</span>
                <span className="font-mono text-slate-400">({run.branch})</span>
                <span className="font-mono text-slate-500 text-[11px]">#{run.commitHash}</span>
                <span className="text-slate-400 truncate max-w-sm hidden md:inline">
                  · {run.commitMessage}
                </span>
              </div>

              <div className="flex items-center gap-3 font-mono text-[11px]">
                <span className="text-slate-400">{run.startedAt}</span>
                <span className="text-slate-500">({run.duration})</span>
                {run.status === 'success' ? (
                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    Success
                  </span>
                ) : (
                  <span className="text-amber-400 font-semibold flex items-center gap-1 animate-pulse">
                    <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                    Running
                  </span>
                )}
              </div>
            </div>

            {/* Stages Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-850">
              {run.stages.map((stg) => (
                <div
                  key={stg.name}
                  className="p-2.5 rounded bg-slate-950 border border-slate-850 text-xs font-mono"
                >
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="truncate">{stg.name}</span>
                    <span className="text-[10px] text-slate-500">{stg.duration}</span>
                  </div>
                  <div className="mt-1 text-[10px] uppercase font-bold">
                    {stg.status === 'success' && <span className="text-emerald-400">Passed</span>}
                    {stg.status === 'running' && <span className="text-amber-400">Running...</span>}
                    {stg.status === 'queued' && <span className="text-slate-600">Queued</span>}
                    {stg.status === 'failed' && <span className="text-rose-400">Failed</span>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
