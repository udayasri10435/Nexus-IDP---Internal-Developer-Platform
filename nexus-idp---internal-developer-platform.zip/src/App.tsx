import React from 'react';
import { IDPProvider, useIDP } from './context/IDPContext';
import { Header } from './components/Header';
import { ServiceCatalogView } from './components/ServiceCatalogView';
import { GoldenPathsView } from './components/GoldenPathsView';
import { KubernetesView } from './components/KubernetesView';
import { TerraformView } from './components/TerraformView';
import { CicdGitOpsView } from './components/CicdGitOpsView';
import { FinOpsCostView } from './components/FinOpsCostView';
import { ServiceDetailModal } from './components/ServiceDetailModal';
import { ProvisioningWizardModal } from './components/ProvisioningWizardModal';
import {
  Activity,
  Layers,
  Server,
  Terminal,
  Workflow,
  DollarSign,
  GitBranch,
} from 'lucide-react';

const MainContent: React.FC = () => {
  const { activeTab, selectedService, setSelectedService, activities } = useIDP();

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100 selection:bg-indigo-500/20 selection:text-indigo-200">
      <Header />

      {/* Main Container Viewport (1440px standard max-w) */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'catalog' && <ServiceCatalogView />}
        {activeTab === 'provisioner' && <GoldenPathsView />}
        {activeTab === 'kubernetes' && <KubernetesView />}
        {activeTab === 'terraform' && <TerraformView />}
        {activeTab === 'cicd' && <CicdGitOpsView />}
        {activeTab === 'finops' && <FinOpsCostView />}
      </main>

      {/* Quiet Audit & Activity Strip */}
      <div className="border-t border-slate-800/80 bg-slate-950/80 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-col md:flex-row items-center justify-between gap-3 text-slate-500">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-slate-400 flex items-center gap-1.5">
              <Activity className="h-3.5 w-3.5 text-indigo-400" />
              Latest Platform Event:
            </span>
            <span className="text-slate-300 font-mono text-[11px] truncate max-w-md">
              {activities[0]?.actor} {activities[0]?.action} on {activities[0]?.target} ({activities[0]?.timestamp})
            </span>
          </div>

          <div className="flex items-center gap-3 text-[11px]">
            <span>Nexus Internal Developer Platform</span>
            <span aria-hidden="true">·</span>
            <span>Backstage Architecture</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-400 font-mono">System Nominal</span>
          </div>
        </div>
      </div>

      {/* Modals & Slide-overs */}
      {selectedService && (
        <ServiceDetailModal
          service={selectedService}
          onClose={() => setSelectedService(null)}
        />
      )}

      <ProvisioningWizardModal />
    </div>
  );
};

export default function App() {
  return (
    <IDPProvider>
      <MainContent />
    </IDPProvider>
  );
}
