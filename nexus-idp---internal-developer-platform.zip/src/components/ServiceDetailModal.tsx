import React, { useState } from 'react';
import { useIDP } from '../context/IDPContext';
import { ServiceEntity } from '../types/idp';
import {
  X,
  Layers,
  Server,
  Terminal,
  GitBranch,
  DollarSign,
  FileCode,
  Network,
  ExternalLink,
  RefreshCw,
  Play,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Sliders,
  Check,
  ChevronRight,
} from 'lucide-react';

interface ServiceDetailModalProps {
  service: ServiceEntity;
  onClose: () => void;
}

export const ServiceDetailModal: React.FC<ServiceDetailModalProps> = ({ service, onClose }) => {
  const {
    pods,
    workspaces,
    pipelines,
    scaleServiceReplicas,
    restartPod,
    runTerraformPlan,
    triggerPipelineRun,
    applyCostRecommendation,
    costRecommendations,
  } = useIDP();

  const [activeTab, setActiveTab] = useState<
    'overview' | 'kubernetes' | 'terraform' | 'cicd' | 'finops' | 'api' | 'graph'
  >('overview');

  const [replicaInput, setReplicaInput] = useState<number>(service.replicas.target);
  const [selectedPodForLogs, setSelectedPodForLogs] = useState<string | null>(null);

  // Find pods belonging to this service namespace or name prefix
  const servicePods = pods.filter(
    (p) => p.namespace === service.namespace || p.name.startsWith(service.name)
  );

  // Find matching workspace
  const workspace = workspaces.find((w) => w.id === service.terraformWorkspaceId);

  // Find pipeline runs
  const servicePipelines = pipelines.filter((p) => p.serviceId === service.id);

  // Find cost recommendations for this service
  const serviceRecommendations = costRecommendations.filter(
    (r) => r.serviceId === service.id && r.status === 'available'
  );

  const activePod = servicePods.find((p) => p.name === selectedPodForLogs) || servicePods[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/60 backdrop-blur-xs transition-opacity animate-in fade-in duration-200">
      <div className="h-full w-full max-w-4xl bg-slate-950 border-l border-slate-800 flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/80">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
              <Layers className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">{service.displayName}</h2>
                <span className="font-mono text-xs text-slate-400">({service.name})</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                <span>{service.ownerTeam}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono uppercase">{service.tier}</span>
                <span aria-hidden="true">·</span>
                <span className="capitalize">{service.lifecycle}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono">{service.cluster}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => triggerPipelineRun(service.id)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-md transition-colors"
            >
              <RefreshCw className="h-3 w-3" />
              <span>Deploy Release</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-md transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Tab Strip */}
        <div className="flex items-center gap-1 px-6 border-b border-slate-800 bg-slate-900/40 text-xs overflow-x-auto">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3 py-2.5 font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'overview'
                ? 'border-indigo-500 text-white font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('kubernetes')}
            className={`px-3 py-2.5 font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'kubernetes'
                ? 'border-indigo-500 text-white font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Server className="h-3.5 w-3.5" />
            <span>Kubernetes ({service.replicas.current} Pods)</span>
          </button>
          <button
            onClick={() => setActiveTab('terraform')}
            className={`px-3 py-2.5 font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'terraform'
                ? 'border-indigo-500 text-white font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="h-3.5 w-3.5" />
            <span>Terraform State</span>
            {workspace?.driftDetected && (
              <span className="h-1.5 w-1.5 rounded-full bg-amber-400"></span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('cicd')}
            className={`px-3 py-2.5 font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'cicd'
                ? 'border-indigo-500 text-white font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <GitBranch className="h-3.5 w-3.5" />
            <span>CI/CD & GitOps</span>
          </button>
          <button
            onClick={() => setActiveTab('finops')}
            className={`px-3 py-2.5 font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'finops'
                ? 'border-indigo-500 text-white font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <DollarSign className="h-3.5 w-3.5" />
            <span>FinOps (${service.costMonthly}/mo)</span>
          </button>
          <button
            onClick={() => setActiveTab('api')}
            className={`px-3 py-2.5 font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'api'
                ? 'border-indigo-500 text-white font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="h-3.5 w-3.5" />
            <span>APIs & Schema</span>
          </button>
          <button
            onClick={() => setActiveTab('graph')}
            className={`px-3 py-2.5 font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'graph'
                ? 'border-indigo-500 text-white font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Network className="h-3.5 w-3.5" />
            <span>Dependencies</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Description */}
              <div className="p-4 rounded-lg bg-slate-900/60 border border-slate-800">
                <span className="text-xs font-semibold text-slate-300">About this Service</span>
                <p className="mt-1 text-xs text-slate-400 leading-relaxed">
                  {service.description}
                </p>
                <div className="mt-3 flex flex-wrap gap-4 text-xs text-slate-400">
                  <a
                    href={service.repoUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 text-indigo-400 hover:text-indigo-300"
                  >
                    <span>Git Repository</span>
                    <ExternalLink className="h-3 w-3" />
                  </a>
                  <a
                    href={service.docsUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 text-indigo-400 hover:text-indigo-300"
                  >
                    <span>Platform Documentation</span>
                    <ExternalLink className="h-3 w-3" />
                  </a>
                  <span className="text-slate-500 font-mono">
                    Language: {service.language.toUpperCase()}
                  </span>
                </div>
              </div>

              {/* Resource & SLO Matrix */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-3.5 rounded-lg bg-slate-900/40 border border-slate-800">
                  <span className="text-[11px] text-slate-500">CPU Usage / Request</span>
                  <div className="mt-1 font-mono text-sm font-semibold text-slate-200">
                    {service.resources.cpuUsage}
                  </div>
                  <span className="text-[10px] text-slate-500">
                    Req: {service.resources.cpuRequest} · Lim: {service.resources.cpuLimit}
                  </span>
                </div>

                <div className="p-3.5 rounded-lg bg-slate-900/40 border border-slate-800">
                  <span className="text-[11px] text-slate-500">Memory Usage</span>
                  <div className="mt-1 font-mono text-sm font-semibold text-slate-200">
                    {service.resources.memoryUsage}
                  </div>
                  <span className="text-[10px] text-slate-500">
                    Req: {service.resources.memoryRequest} · Lim: {service.resources.memoryLimit}
                  </span>
                </div>

                <div className="p-3.5 rounded-lg bg-slate-900/40 border border-slate-800">
                  <span className="text-[11px] text-slate-500">Autoscaling (HPA)</span>
                  <div className="mt-1 font-mono text-sm font-semibold text-slate-200">
                    {service.replicas.min} to {service.replicas.max} replicas
                  </div>
                  <span className="text-[10px] text-slate-500">Target CPU Utilization 75%</span>
                </div>

                <div className="p-3.5 rounded-lg bg-slate-900/40 border border-slate-800">
                  <span className="text-[11px] text-slate-500">GitOps Sync Status</span>
                  <div className="mt-1 flex items-center gap-1.5 font-mono text-sm font-semibold text-emerald-400 capitalize">
                    <CheckCircle2 className="h-4 w-4" />
                    {service.gitopsSyncStatus}
                  </div>
                  <span className="text-[10px] text-slate-500">Last commit {service.lastDeployedAt}</span>
                </div>
              </div>

              {/* Service Relationships Quick View */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-slate-900/40 border border-slate-800">
                  <span className="text-xs font-semibold text-slate-300">Upstream Dependencies</span>
                  <div className="mt-2 space-y-1.5">
                    {service.dependsOn.length > 0 ? (
                      service.dependsOn.map((dep) => (
                        <div
                          key={dep}
                          className="flex items-center justify-between text-xs py-1 px-2.5 rounded bg-slate-850 text-slate-300 font-mono"
                        >
                          <span>{dep}</span>
                          <span className="text-[10px] text-slate-500">required</span>
                        </div>
                      ))
                    ) : (
                      <span className="text-xs text-slate-500">None (Root service)</span>
                    )}
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-slate-900/40 border border-slate-800">
                  <span className="text-xs font-semibold text-slate-300">Downstream Consumers</span>
                  <div className="mt-2 space-y-1.5">
                    {service.consumedBy.length > 0 ? (
                      service.consumedBy.map((c) => (
                        <div
                          key={c}
                          className="flex items-center justify-between text-xs py-1 px-2.5 rounded bg-slate-850 text-slate-300 font-mono"
                        >
                          <span>{c}</span>
                          <span className="text-[10px] text-indigo-400">client caller</span>
                        </div>
                      ))
                    ) : (
                      <span className="text-xs text-slate-500">No registered downstream consumers</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: KUBERNETES WORKLOADS & LOGS */}
          {activeTab === 'kubernetes' && (
            <div className="space-y-6">
              {/* Interactive Replica Scaler */}
              <div className="p-4 rounded-lg bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-xs font-semibold text-slate-200">Scale Workload Replicas</span>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Currently running {service.replicas.current} pods. Min: {service.replicas.min}, Max: {service.replicas.max}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex items-center border border-slate-700 rounded-md bg-slate-950 overflow-hidden font-mono">
                    <button
                      onClick={() => setReplicaInput(Math.max(1, replicaInput - 1))}
                      className="px-2.5 py-1 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                    >
                      -
                    </button>
                    <span className="px-3 text-xs font-semibold text-white tabular-nums">
                      {replicaInput}
                    </span>
                    <button
                      onClick={() => setReplicaInput(Math.min(32, replicaInput + 1))}
                      className="px-2.5 py-1 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                    >
                      +
                    </button>
                  </div>
                  <button
                    onClick={() => scaleServiceReplicas(service.id, replicaInput)}
                    className="px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-md transition-colors"
                  >
                    Apply Scale Target
                  </button>
                </div>
              </div>

              {/* Active Pods Table */}
              <div>
                <span className="text-xs font-semibold text-slate-300">Live Pod Instances</span>
                <div className="mt-2 overflow-x-auto rounded-lg border border-slate-800">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-900 border-b border-slate-800 text-[11px] text-slate-400 font-mono">
                        <th className="py-2.5 px-3">Pod Name</th>
                        <th className="py-2.5 px-3">Status</th>
                        <th className="py-2.5 px-3">Restarts</th>
                        <th className="py-2.5 px-3">CPU / Mem</th>
                        <th className="py-2.5 px-3">Node</th>
                        <th className="py-2.5 px-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850 font-mono">
                      {servicePods.length > 0 ? (
                        servicePods.map((pod) => (
                          <tr
                            key={pod.name}
                            onClick={() => setSelectedPodForLogs(pod.name)}
                            className={`cursor-pointer transition-colors ${
                              activePod?.name === pod.name
                                ? 'bg-indigo-950/30'
                                : 'hover:bg-slate-900/50'
                            }`}
                          >
                            <td className="py-2.5 px-3 font-semibold text-slate-200">
                              {pod.name}
                            </td>
                            <td className="py-2.5 px-3">
                              {pod.status === 'Running' ? (
                                <span className="text-emerald-400 flex items-center gap-1">
                                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
                                  Running
                                </span>
                              ) : (
                                <span className="text-rose-400 flex items-center gap-1">
                                  <span className="h-1.5 w-1.5 rounded-full bg-rose-500"></span>
                                  {pod.status}
                                </span>
                              )}
                            </td>
                            <td className="py-2.5 px-3 text-slate-400 tabular-nums">
                              {pod.restarts}
                            </td>
                            <td className="py-2.5 px-3 text-slate-400">
                              {pod.cpuUsage} / {pod.memUsage}
                            </td>
                            <td className="py-2.5 px-3 text-slate-500 text-[11px]">
                              {pod.node}
                            </td>
                            <td className="py-2.5 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                              <button
                                onClick={() => restartPod(pod.name)}
                                className="px-2 py-1 text-[11px] text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors"
                              >
                                Restart
                              </button>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={6} className="py-4 text-center text-slate-500">
                            No pods mapped to namespace {service.namespace}
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Live Terminal Log Streamer */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-slate-300">
                    Live Container Logs: <span className="font-mono text-indigo-400">{activePod?.name || 'Container'}</span>
                  </span>
                  <span className="text-[11px] font-mono text-slate-500">tail -f 50 lines</span>
                </div>
                <div className="p-3 rounded-lg bg-black border border-slate-800 font-mono text-xs text-slate-300 h-52 overflow-y-auto space-y-1">
                  {activePod && activePod.logs.length > 0 ? (
                    activePod.logs.map((line, idx) => (
                      <div
                        key={idx}
                        className={`leading-relaxed ${
                          line.includes('[ERROR]') || line.includes('[FATAL]')
                            ? 'text-rose-400'
                            : line.includes('[WARN]')
                            ? 'text-amber-300'
                            : 'text-slate-300'
                        }`}
                      >
                        {line}
                      </div>
                    ))
                  ) : (
                    <div className="text-slate-600">No active log stream received.</div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: TERRAFORM IAC & STATE */}
          {activeTab === 'terraform' && (
            <div className="space-y-6">
              {workspace ? (
                <>
                  <div className="p-4 rounded-lg bg-slate-900/60 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-white">{workspace.name}</span>
                        <span className="text-xs font-mono text-slate-400">({workspace.stateVersion})</span>
                      </div>
                      <div className="text-xs text-slate-400 mt-1">
                        State lock: <span className="font-mono uppercase">{workspace.lockStatus}</span> · Last run {workspace.lastRunTime} · {workspace.resourcesCount} managed cloud resources
                      </div>
                    </div>

                    <button
                      onClick={() => runTerraformPlan(workspace.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-md transition-colors"
                    >
                      <Play className="h-3 w-3" />
                      <span>Run Terraform Plan</span>
                    </button>
                  </div>

                  {/* Drift Warning Banner if detected */}
                  {workspace.driftDetected && (
                    <div className="p-4 rounded-lg bg-amber-950/30 border border-amber-800/60 flex items-start gap-3">
                      <AlertTriangle className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="text-xs font-semibold text-amber-200">
                          Infrastructure Drift Detected!
                        </span>
                        <p className="text-xs text-amber-300/80 mt-1">
                          Manual adjustments were made directly on the Kubernetes cluster outside of Terraform code.
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Plan Diff Viewer */}
                  <div>
                    <span className="text-xs font-semibold text-slate-300">Terraform Plan Execution Output</span>
                    <pre className="mt-2 p-3.5 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono text-slate-300 overflow-x-auto whitespace-pre leading-relaxed">
                      {workspace.planDiff}
                    </pre>
                  </div>

                  {/* Managed Cloud Resources */}
                  <div>
                    <span className="text-xs font-semibold text-slate-300">Managed Cloud Resources</span>
                    <div className="mt-2 divide-y divide-slate-850 rounded-lg border border-slate-800 bg-slate-900/30 overflow-hidden text-xs font-mono">
                      {workspace.managedResources.map((res) => (
                        <div key={res.id} className="py-2.5 px-3.5 flex items-center justify-between">
                          <div>
                            <span className="text-indigo-400 font-semibold">{res.type}</span>
                            <span className="text-slate-500 ml-2">.{res.name}</span>
                          </div>
                          <span className="text-[11px] text-slate-400 truncate max-w-xs">{res.id}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              ) : (
                <div className="py-8 text-center text-xs text-slate-500">
                  No linked Terraform workspace configured for this service.
                </div>
              )}
            </div>
          )}

          {/* TAB 4: CI/CD & GITOPS */}
          {activeTab === 'cicd' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-slate-200">GitOps & Pipeline Runs</span>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Automated build, test, container push, and ArgoCD synchronization
                  </p>
                </div>
                <button
                  onClick={() => triggerPipelineRun(service.id)}
                  className="px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-md transition-colors"
                >
                  Trigger Pipeline
                </button>
              </div>

              <div className="space-y-3">
                {servicePipelines.map((run) => (
                  <div
                    key={run.id}
                    className="p-4 rounded-lg bg-slate-900/60 border border-slate-800 space-y-3"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-semibold text-slate-200">{run.branch}</span>
                        <span className="font-mono text-[11px] text-slate-500">#{run.commitHash}</span>
                        <span className="text-slate-400">· {run.commitMessage}</span>
                      </div>
                      <div className="flex items-center gap-2 font-mono">
                        <span className="text-slate-400">{run.duration}</span>
                        {run.status === 'success' ? (
                          <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            Success
                          </span>
                        ) : run.status === 'running' ? (
                          <span className="text-amber-400 flex items-center gap-1 font-semibold animate-pulse">
                            <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                            Running
                          </span>
                        ) : (
                          <span className="text-rose-400 font-semibold">Failed</span>
                        )}
                      </div>
                    </div>

                    {/* Stage Timeline */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-800">
                      {run.stages.map((stg) => (
                        <div
                          key={stg.name}
                          className="p-2 rounded bg-slate-950 border border-slate-850 text-[11px]"
                        >
                          <div className="flex items-center justify-between text-slate-400">
                            <span className="truncate">{stg.name}</span>
                            <span className="font-mono text-[10px]">{stg.duration}</span>
                          </div>
                          <div className="mt-1 font-mono uppercase text-[10px] font-semibold">
                            {stg.status === 'success' && <span className="text-emerald-400">Passed</span>}
                            {stg.status === 'running' && <span className="text-amber-400">In Progress</span>}
                            {stg.status === 'queued' && <span className="text-slate-500">Queued</span>}
                            {stg.status === 'failed' && <span className="text-rose-400">Failed</span>}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: FINOPS & COSTS */}
          {activeTab === 'finops' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 rounded-lg bg-slate-900/60 border border-slate-800">
                  <span className="text-xs text-slate-400">Monthly Run Rate</span>
                  <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-white">
                    ${service.costMonthly.toLocaleString()}
                  </div>
                  <span className="text-[11px] text-slate-500">Based on active resource commitments</span>
                </div>

                <div className="p-4 rounded-lg bg-slate-900/60 border border-slate-800">
                  <span className="text-xs text-slate-400">Unit Economics</span>
                  <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-indigo-400">
                    $0.024
                  </div>
                  <span className="text-[11px] text-slate-500">Cost per 1,000 processed requests</span>
                </div>

                <div className="p-4 rounded-lg bg-slate-900/60 border border-slate-800">
                  <span className="text-xs text-slate-400">Available Optimizations</span>
                  <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-emerald-400">
                    ${serviceRecommendations.reduce((acc, r) => acc + r.potentialSavingsMonthly, 0)}/mo
                  </div>
                  <span className="text-[11px] text-slate-500">Immediate right-sizing potential</span>
                </div>
              </div>

              {/* Actionable Recommendations */}
              <div>
                <span className="text-xs font-semibold text-slate-200">Active FinOps Recommendations</span>
                <div className="mt-2 space-y-3">
                  {serviceRecommendations.length > 0 ? (
                    serviceRecommendations.map((rec) => (
                      <div
                        key={rec.id}
                        className="p-4 rounded-lg bg-emerald-950/20 border border-emerald-900/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-semibold text-emerald-300">{rec.title}</span>
                            <span className="font-mono text-xs text-emerald-400 font-bold">
                              Save ${rec.potentialSavingsMonthly}/mo
                            </span>
                          </div>
                          <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                            {rec.description}
                          </p>
                        </div>
                        <button
                          onClick={() => applyCostRecommendation(rec.id)}
                          className="px-3 py-1.5 text-xs font-semibold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors whitespace-nowrap"
                        >
                          Apply Optimization
                        </button>
                      </div>
                    ))
                  ) : (
                    <div className="py-6 text-center text-xs text-slate-500 border border-dashed border-slate-800 rounded-lg">
                      No active cost anomalies or over-provisioning warnings for this service.
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: API SPECS */}
          {activeTab === 'api' && (
            <div className="space-y-4">
              <span className="text-xs font-semibold text-slate-300">Provided API Endpoints & Interfaces</span>
              <div className="space-y-2">
                {service.providesApis.map((api) => (
                  <div
                    key={api}
                    className="p-3.5 rounded-lg bg-slate-900/60 border border-slate-800 flex items-center justify-between"
                  >
                    <div>
                      <div className="text-xs font-semibold text-slate-200 font-mono">{api}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        gRPC proto spec + REST HTTP/2 transcoding enabled
                      </div>
                    </div>
                    <span className="text-xs font-mono text-indigo-400">OpenAPI 3.1</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 7: DEPENDENCY GRAPH */}
          {activeTab === 'graph' && (
            <div className="p-6 rounded-lg bg-slate-900/40 border border-slate-800 text-center space-y-6">
              <span className="text-xs font-semibold text-slate-300">Topology & Blast Radius Map</span>
              <div className="flex flex-col md:flex-row items-center justify-center gap-6 py-4">
                {/* Upstream */}
                <div className="space-y-2">
                  <span className="text-[11px] font-mono text-slate-400">Upstream Dependencies</span>
                  {service.dependsOn.map((d) => (
                    <div key={d} className="px-3 py-2 rounded bg-slate-800 border border-slate-700 text-xs font-mono text-slate-200">
                      {d}
                    </div>
                  ))}
                </div>

                <div className="text-slate-500 text-sm">→</div>

                {/* Target */}
                <div className="px-4 py-3 rounded-lg bg-indigo-600/30 border border-indigo-500 text-xs font-bold text-white font-mono shadow-md">
                  {service.name} (Current)
                </div>

                <div className="text-slate-500 text-sm">→</div>

                {/* Downstream */}
                <div className="space-y-2">
                  <span className="text-[11px] font-mono text-slate-400">Downstream Callers</span>
                  {service.consumedBy.length > 0 ? (
                    service.consumedBy.map((c) => (
                      <div key={c} className="px-3 py-2 rounded bg-slate-800 border border-slate-700 text-xs font-mono text-slate-200">
                        {c}
                      </div>
                    ))
                  ) : (
                    <div className="text-xs text-slate-500 font-mono">No downstream callers</div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
