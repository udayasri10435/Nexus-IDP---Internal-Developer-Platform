import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  ServiceEntity,
  GoldenPathTemplate,
  K8sCluster,
  K8sPod,
  TerraformWorkspace,
  CostRecommendation,
  PipelineRun,
  ActivityEvent,
  ProvisioningJob,
} from '../types/idp';
import {
  INITIAL_SERVICES,
  GOLDEN_PATH_TEMPLATES,
  INITIAL_CLUSTERS,
  INITIAL_PODS,
  INITIAL_WORKSPACES,
  INITIAL_COST_RECOMMENDATIONS,
  INITIAL_PIPELINES,
  INITIAL_ACTIVITIES,
} from '../data/mockData';

interface IDPContextType {
  services: ServiceEntity[];
  templates: GoldenPathTemplate[];
  clusters: K8sCluster[];
  pods: K8sPod[];
  workspaces: TerraformWorkspace[];
  costRecommendations: CostRecommendation[];
  pipelines: PipelineRun[];
  activities: ActivityEvent[];
  selectedService: ServiceEntity | null;
  setSelectedService: (svc: ServiceEntity | null) => void;
  selectedClusterId: string;
  setSelectedClusterId: (clusterId: string) => void;
  activeTab: 'catalog' | 'provisioner' | 'kubernetes' | 'terraform' | 'cicd' | 'finops';
  setActiveTab: (tab: 'catalog' | 'provisioner' | 'kubernetes' | 'terraform' | 'cicd' | 'finops') => void;
  isProvisionModalOpen: boolean;
  setIsProvisionModalOpen: (open: boolean) => void;
  activeProvisionJob: ProvisioningJob | null;
  setActiveProvisionJob: (job: ProvisioningJob | null) => void;
  startProvisioning: (job: ProvisioningJob) => void;
  scaleServiceReplicas: (serviceId: string, newTarget: number) => void;
  restartPod: (podName: string) => void;
  runTerraformPlan: (workspaceId: string) => void;
  applyCostRecommendation: (recId: string) => void;
  triggerPipelineRun: (serviceId: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

const IDPContext = createContext<IDPContextType | undefined>(undefined);

export const IDPProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [services, setServices] = useState<ServiceEntity[]>(() => {
    const saved = localStorage.getItem('nexus_idp_services');
    return saved ? JSON.parse(saved) : INITIAL_SERVICES;
  });

  const [templates] = useState<GoldenPathTemplate[]>(GOLDEN_PATH_TEMPLATES);

  const [clusters, setClusters] = useState<K8sCluster[]>(INITIAL_CLUSTERS);
  const [pods, setPods] = useState<K8sPod[]>(INITIAL_PODS);
  const [workspaces, setWorkspaces] = useState<TerraformWorkspace[]>(INITIAL_WORKSPACES);
  const [costRecommendations, setCostRecommendations] = useState<CostRecommendation[]>(INITIAL_COST_RECOMMENDATIONS);
  const [pipelines, setPipelines] = useState<PipelineRun[]>(INITIAL_PIPELINES);
  const [activities, setActivities] = useState<ActivityEvent[]>(INITIAL_ACTIVITIES);

  const [selectedService, setSelectedService] = useState<ServiceEntity | null>(null);
  const [selectedClusterId, setSelectedClusterId] = useState<string>('aws-us-east-1-prod');
  const [activeTab, setActiveTab] = useState<'catalog' | 'provisioner' | 'kubernetes' | 'terraform' | 'cicd' | 'finops'>('catalog');
  const [isProvisionModalOpen, setIsProvisionModalOpen] = useState<boolean>(false);
  const [activeProvisionJob, setActiveProvisionJob] = useState<ProvisioningJob | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  useEffect(() => {
    localStorage.setItem('nexus_idp_services', JSON.stringify(services));
  }, [services]);

  const scaleServiceReplicas = (serviceId: string, newTarget: number) => {
    setServices((prev) =>
      prev.map((svc) => {
        if (svc.id === serviceId) {
          const updated = {
            ...svc,
            replicas: {
              ...svc.replicas,
              current: newTarget,
              target: newTarget,
            },
          };
          if (selectedService?.id === serviceId) {
            setSelectedService(updated);
          }
          return updated;
        }
        return svc;
      })
    );

    // Record activity
    const newAct: ActivityEvent = {
      id: `act-${Date.now()}`,
      timestamp: 'Just now',
      actor: 'Platform Engineer',
      action: `Scaled deployment target to ${newTarget} replicas`,
      target: serviceId,
      type: 'scale',
    };
    setActivities((prev) => [newAct, ...prev]);
  };

  const restartPod = (podName: string) => {
    setPods((prev) =>
      prev.map((p) => {
        if (p.name === podName) {
          return {
            ...p,
            status: 'Running',
            restarts: p.restarts + 1,
            logs: [
              ...p.logs,
              `[INFO] ${new Date().toISOString()} [K8s] Graceful SIGTERM dispatched. Container restarted successfully.`,
            ],
          };
        }
        return p;
      })
    );
  };

  const runTerraformPlan = (workspaceId: string) => {
    setWorkspaces((prev) =>
      prev.map((ws) => {
        if (ws.id === workspaceId) {
          return {
            ...ws,
            driftDetected: false,
            lastRunTime: 'Just now',
            planPending: false,
            planDiff: `# Terraform Plan output [refreshed just now]
All remote resources in synchronization with state file.
Plan: 0 to add, 0 to change, 0 to destroy.
Workspace state verified clean.`,
          };
        }
        return ws;
      })
    );

    const newAct: ActivityEvent = {
      id: `act-${Date.now()}`,
      timestamp: 'Just now',
      actor: 'Platform Engineer',
      action: `Re-applied Terraform configuration and resolved drift`,
      target: workspaceId,
      type: 'terraform',
    };
    setActivities((prev) => [newAct, ...prev]);
  };

  const applyCostRecommendation = (recId: string) => {
    const rec = costRecommendations.find((r) => r.id === recId);
    if (!rec) return;

    // Update recommendation status
    setCostRecommendations((prev) =>
      prev.map((r) => (r.id === recId ? { ...r, status: 'applied' } : r))
    );

    // Update service cost
    setServices((prev) =>
      prev.map((svc) => {
        if (svc.id === rec.serviceId) {
          const newCost = Math.max(20, svc.costMonthly - rec.potentialSavingsMonthly);
          const updated = {
            ...svc,
            costMonthly: newCost,
            costTrendPercent: -15.2,
          };
          if (selectedService?.id === svc.id) {
            setSelectedService(updated);
          }
          return updated;
        }
        return svc;
      })
    );

    // Add activity
    const newAct: ActivityEvent = {
      id: `act-${Date.now()}`,
      timestamp: 'Just now',
      actor: 'FinOps Automation',
      action: `Applied optimization "${rec.title}" (saved $${rec.potentialSavingsMonthly}/mo)`,
      target: rec.serviceName,
      type: 'cost_opt',
    };
    setActivities((prev) => [newAct, ...prev]);
  };

  const triggerPipelineRun = (serviceId: string) => {
    const svc = services.find((s) => s.id === serviceId);
    if (!svc) return;

    const newRun: PipelineRun = {
      id: `pipe-${Date.now().toString().slice(-4)}`,
      serviceId,
      serviceName: svc.name,
      branch: 'main',
      commitHash: Math.random().toString(36).substring(2, 9),
      commitMessage: 'chore(platform): manual deploy triggered via IDP console',
      author: 'platform.user@nexus.internal',
      status: 'running',
      duration: '12s',
      startedAt: 'Just now',
      stages: [
        { name: 'Lint & Vet', status: 'success', duration: '8s' },
        { name: 'Unit Tests', status: 'running', duration: '12s' },
        { name: 'Docker Build', status: 'queued', duration: '0s' },
        { name: 'GitOps ArgoCD Sync', status: 'queued', duration: '0s' },
      ],
    };

    setPipelines((prev) => [newRun, ...prev]);

    // Simulate completion after 4 seconds
    setTimeout(() => {
      setPipelines((prev) =>
        prev.map((p) =>
          p.id === newRun.id
            ? {
                ...p,
                status: 'success',
                duration: '1m 24s',
                stages: p.stages.map((s) => ({ ...s, status: 'success' })),
              }
            : p
        )
      );
    }, 4000);
  };

  const startProvisioning = (job: ProvisioningJob) => {
    setActiveProvisionJob(job);

    // Step-by-step pipeline runner simulation
    let currentStep = 0;
    const interval = setInterval(() => {
      currentStep++;
      if (currentStep < job.steps.length) {
        setActiveProvisionJob((prev) => {
          if (!prev) return null;
          const updatedSteps = prev.steps.map((st, idx) => {
            if (idx < currentStep) return { ...st, status: 'completed' as const };
            if (idx === currentStep) return { ...st, status: 'running' as const };
            return { ...st, status: 'pending' as const };
          });

          const newLogs = [...prev.logs];
          if (currentStep === 1) {
            newLogs.push({
              timestamp: new Date().toLocaleTimeString(),
              level: 'info',
              message: `[Terraform] Initializing backend s3://nexus-state-${job.environment}/${job.serviceName}...`,
            });
            newLogs.push({
              timestamp: new Date().toLocaleTimeString(),
              level: 'info',
              message: `[Terraform] Provider hashicorp/aws v5.40 loaded. Applying plan (12 resources to create)...`,
            });
          } else if (currentStep === 2) {
            newLogs.push({
              timestamp: new Date().toLocaleTimeString(),
              level: 'info',
              message: `[K8s] Created namespace '${job.environment}-${job.serviceName}' on cluster aws-us-east-1-prod`,
            });
            newLogs.push({
              timestamp: new Date().toLocaleTimeString(),
              level: 'info',
              message: `[Helm] Installed chart ingress-nginx-v4.9 and Datadog APM tracing agent sidecar`,
            });
          } else if (currentStep === 3) {
            newLogs.push({
              timestamp: new Date().toLocaleTimeString(),
              level: 'info',
              message: `[ArgoCD] Created Application resource 'argocd/${job.serviceName}-${job.environment}'`,
            });
            newLogs.push({
              timestamp: new Date().toLocaleTimeString(),
              level: 'success',
              message: `[GitOps] Auto-sync verified: revision HEAD synced to healthy state.`,
            });
          }

          return {
            ...prev,
            currentStepIndex: currentStep,
            steps: updatedSteps,
            logs: newLogs,
          };
        });
      } else {
        clearInterval(interval);
        // Completed! Add new service to catalog
        const newService: ServiceEntity = {
          id: job.serviceName,
          name: job.serviceName,
          displayName: job.displayName || job.serviceName,
          description: `Provisioned via Golden Path '${job.templateTitle}'. Production ready with ArgoCD sync and Datadog monitoring.`,
          kind: 'service',
          system: 'core-platform',
          domain: 'Core Engineering',
          ownerTeam: job.ownerTeam,
          tier: 'tier-2',
          lifecycle: job.environment === 'production' ? 'production' : 'staging',
          language: 'go',
          repoUrl: `https://github.com/enterprise/${job.serviceName}`,
          docsUrl: `https://docs.internal.net/services/${job.serviceName}`,
          healthStatus: 'healthy',
          tags: ['golden-path', job.cloudProvider, job.environment],
          lastDeployedAt: 'Just now',
          costMonthly: job.infracostDiff.newCostMonthly || 85,
          costTrendPercent: 0,
          cluster: 'aws-us-east-1-prod',
          namespace: job.serviceName,
          replicas: {
            current: 3,
            target: 3,
            min: 2,
            max: 8,
          },
          resources: {
            cpuUsage: '0.2 cores',
            cpuRequest: '1.0 cores',
            cpuLimit: '2.0 cores',
            memoryUsage: '0.5 GB',
            memoryRequest: '1.5 GB',
            memoryLimit: '3.0 GB',
          },
          dependsOn: ['auth-gateway'],
          consumedBy: [],
          providesApis: [`${job.serviceName}.v1.Endpoint`],
          gitopsSyncStatus: 'synced',
          terraformWorkspaceId: `ws-${job.serviceName}-${job.environment}`,
          ciPipelineId: `pipe-${job.serviceName}-001`,
        };

        setServices((prev) => [newService, ...prev]);

        // Add pods
        const newPod: K8sPod = {
          name: `${job.serviceName}-79cd4f8-${Math.random().toString(36).substring(2, 6)}`,
          namespace: job.serviceName,
          status: 'Running',
          restarts: 0,
          age: '1m',
          cpuUsage: '65m',
          memUsage: '142Mi',
          ip: '10.244.4.55',
          node: 'ip-10-0-12-88.ec2.internal',
          logs: [
            `[INFO] ${new Date().toISOString()} [Bootstrap] Container initialized from Golden Path image`,
            `[INFO] ${new Date().toISOString()} [Health] Liveness probe listening on :8080/healthz`,
          ],
        };
        setPods((prev) => [newPod, ...prev]);

        // Add Terraform workspace
        const newWs: TerraformWorkspace = {
          id: `ws-${job.serviceName}-${job.environment}`,
          name: `${job.environment}-us-east-1/${job.serviceName}`,
          environment: job.environment === 'production' ? 'production' : 'staging',
          stateVersion: 'v1.0.0',
          lastRunId: `run-${Date.now().toString().slice(-5)}`,
          lastRunTime: 'Just now',
          driftDetected: false,
          resourcesCount: 14,
          monthlyCost: job.infracostDiff.newCostMonthly || 85,
          planPending: false,
          repoPath: `terraform/environments/${job.environment}/${job.serviceName}`,
          lockStatus: 'unlocked',
          managedResources: [
            { type: 'kubernetes_deployment', name: 'app', status: 'created', id: `${job.serviceName}/deployment` },
            { type: 'kubernetes_service', name: 'app_svc', status: 'created', id: `${job.serviceName}/service` },
            { type: 'aws_iam_role', name: 'workload_role', status: 'created', id: `arn:aws:iam::253687723639:role/${job.serviceName}` },
          ],
          planDiff: '# State matches repository configuration. 0 to add, 0 to change.',
        };
        setWorkspaces((prev) => [newWs, ...prev]);

        // Add activity
        const newAct: ActivityEvent = {
          id: `act-${Date.now()}`,
          timestamp: 'Just now',
          actor: 'Platform Engineer',
          action: `Provisioned new Golden Path service "${job.serviceName}"`,
          target: job.serviceName,
          type: 'provision',
        };
        setActivities((prev) => [newAct, ...prev]);

        setActiveProvisionJob((prev) => {
          if (!prev) return null;
          return {
            ...prev,
            status: 'completed',
            completedAt: new Date().toLocaleTimeString(),
            steps: prev.steps.map((s) => ({ ...s, status: 'completed' as const })),
            outputs: {
              ingressUrl: `https://${job.serviceName}.internal.net`,
              argocdApp: `https://argocd.internal.net/applications/${job.serviceName}`,
              gitRepository: `https://github.com/enterprise/${job.serviceName}`,
              metricsDashboard: `https://datadog.internal.net/dashboard/${job.serviceName}`,
            },
            logs: [
              ...prev.logs,
              {
                timestamp: new Date().toLocaleTimeString(),
                level: 'success',
                message: `[Provisioner] Deployment pipeline completed successfully in 48s. Service is online!`,
              },
            ],
          };
        });
      }
    }, 1800);
  };

  return (
    <IDPContext.Provider
      value={{
        services,
        templates,
        clusters,
        pods,
        workspaces,
        costRecommendations,
        pipelines,
        activities,
        selectedService,
        setSelectedService,
        selectedClusterId,
        setSelectedClusterId,
        activeTab,
        setActiveTab,
        isProvisionModalOpen,
        setIsProvisionModalOpen,
        activeProvisionJob,
        setActiveProvisionJob,
        startProvisioning,
        scaleServiceReplicas,
        restartPod,
        runTerraformPlan,
        applyCostRecommendation,
        triggerPipelineRun,
        searchQuery,
        setSearchQuery,
      }}
    >
      {children}
    </IDPContext.Provider>
  );
};

export const useIDP = () => {
  const context = useContext(IDPContext);
  if (!context) {
    throw new Error('useIDP must be used within an IDPProvider');
  }
  return context;
};
