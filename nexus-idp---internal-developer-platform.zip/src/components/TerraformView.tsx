import React, { useState } from 'react';
import { useIDP } from '../context/IDPContext';
import { TerraformWorkspace } from '../types/idp';
import {
  Terminal,
  Play,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Lock,
  Unlock,
  FileCode,
  Layers,
  ExternalLink,
  RefreshCw,
} from 'lucide-react';

export const TerraformView: React.FC = () => {
  const { workspaces, runTerraformPlan } = useIDP();
  const [selectedWorkspaceId, setSelectedWorkspaceId] = useState<string>(workspaces[0]?.id || '');
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [cliOutput, setCliOutput] = useState<string[]>([]);

  const activeWorkspace = workspaces.find((w) => w.id === selectedWorkspaceId) || workspaces[0];

  const handleRunCommand = (command: string) => {
    setIsExecuting(true);
    setCliOutput([
      `$ terraform ${command}`,
      `[Terraform Cloud] Initializing state backend for '${activeWorkspace.name}'...`,
      `[Terraform Cloud] Acquired state lock id=${Math.random().toString(36).substring(2, 10)}`,
      `[Terraform Cloud] Refreshing state... [id=${activeWorkspace.id}]`,
    ]);

    setTimeout(() => {
      if (command === 'apply') {
        runTerraformPlan(activeWorkspace.id);
        setCliOutput((prev) => [
          ...prev,
          `aws_iam_role.service_sa_role: Modifying... [id=arn:aws:iam::253687723639:role]`,
          `kubernetes_deployment.app: Plan applied. Drift resolved.`,
          `Apply complete! Resources: 0 added, 1 changed, 0 destroyed.`,
          `[Terraform Cloud] State lock released.`,
        ]);
      } else if (command === 'plan') {
        runTerraformPlan(activeWorkspace.id);
        setCliOutput((prev) => [
          ...prev,
          `Terraform will perform the following actions:`,
          `~ kubernetes_deployment.app`,
          `    resources.requests.cpu: "1000m" -> "2000m"`,
          `Plan: 0 to add, 1 to change, 0 to destroy.`,
        ]);
      } else {
        setCliOutput((prev) => [
          ...prev,
          ...activeWorkspace.managedResources.map((r) => `${r.type}.${r.name} [id=${r.id}]`),
          `State list complete (${activeWorkspace.managedResources.length} resources found)`,
        ]);
      }
      setIsExecuting(false);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      {/* Intro Header */}
      <div className="p-5 rounded-lg bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white">Terraform Infrastructure as Code Workspaces</h2>
            <span className="font-mono text-xs text-indigo-400">Terraform Cloud API</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Managed state files, continuous drift detection, and automated execution plans.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-400">Total Workspaces:</span>
          <span className="font-bold text-white tabular-nums">{workspaces.length}</span>
          <span className="text-slate-600">·</span>
          <span className="text-amber-400 font-semibold">
            {workspaces.filter((w) => w.driftDetected).length} Drifted
          </span>
        </div>
      </div>

      {/* Main Grid: Workspaces List (left) + Active Workspace & CLI Runner (right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Workspace selector (4 cols) */}
        <div className="lg:col-span-4 space-y-3">
          <span className="text-xs font-semibold text-slate-300">Managed Workspaces</span>
          <div className="space-y-2">
            {workspaces.map((ws) => (
              <div
                key={ws.id}
                onClick={() => setSelectedWorkspaceId(ws.id)}
                className={`p-3.5 rounded-lg border cursor-pointer transition-all ${
                  selectedWorkspaceId === ws.id
                    ? 'bg-indigo-950/30 border-indigo-500 shadow-md ring-1 ring-indigo-500/40'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="font-semibold text-xs text-white truncate max-w-[200px]">
                    {ws.name}
                  </div>
                  {ws.driftDetected ? (
                    <span className="text-[10px] font-mono font-bold text-amber-400 uppercase flex items-center gap-1">
                      <AlertTriangle className="h-3 w-3" />
                      Drifted
                    </span>
                  ) : (
                    <span className="text-[10px] font-mono text-emerald-400 uppercase flex items-center gap-1">
                      <CheckCircle2 className="h-3 w-3" />
                      Clean
                    </span>
                  )}
                </div>

                <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>{ws.resourcesCount} resources</span>
                  <span>${ws.monthlyCost}/mo</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Workspace Details & CLI Runner (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="p-4 rounded-lg bg-slate-900/60 border border-slate-800 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-white font-mono">{activeWorkspace.name}</h3>
                <span className="text-xs text-slate-400 font-mono">
                  Repo: {activeWorkspace.repoPath} · State: {activeWorkspace.stateVersion}
                </span>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2">
                <button
                  disabled={isExecuting}
                  onClick={() => handleRunCommand('plan')}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-md transition-colors disabled:opacity-50"
                >
                  <Play className="h-3 w-3" />
                  <span>terraform plan</span>
                </button>
                <button
                  disabled={isExecuting}
                  onClick={() => handleRunCommand('apply')}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-md transition-colors disabled:opacity-50"
                >
                  <RefreshCw className={`h-3 w-3 ${isExecuting ? 'animate-spin' : ''}`} />
                  <span>terraform apply</span>
                </button>
              </div>
            </div>

            {/* Drift Banner */}
            {activeWorkspace.driftDetected && (
              <div className="p-3.5 rounded-lg bg-amber-950/30 border border-amber-800/60 text-xs text-amber-200 flex items-start gap-2.5">
                <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold">State Drift Detected: </span>
                  Remote infrastructure parameters do not match code in version control. Click "terraform apply" to reconcile.
                </div>
              </div>
            )}

            {/* CLI Output Terminal */}
            <div>
              <span className="text-xs font-semibold text-slate-300">Terraform Output Console</span>
              <div className="mt-1.5 p-3 rounded-lg bg-black border border-slate-800 font-mono text-xs text-slate-300 h-52 overflow-y-auto space-y-1 leading-relaxed">
                {cliOutput.length > 0 ? (
                  cliOutput.map((line, idx) => (
                    <div
                      key={idx}
                      className={
                        line.startsWith('$')
                          ? 'text-indigo-400 font-bold'
                          : line.includes('Drift') || line.includes('Modifying')
                          ? 'text-amber-300'
                          : line.includes('complete') || line.includes('Clean')
                          ? 'text-emerald-400'
                          : 'text-slate-300'
                      }
                    >
                      {line}
                    </div>
                  ))
                ) : (
                  <pre className="text-slate-300 whitespace-pre">
                    {activeWorkspace.planDiff}
                  </pre>
                )}
              </div>
            </div>

            {/* Managed Resources List */}
            <div>
              <span className="text-xs font-semibold text-slate-300">
                Managed State Resources ({activeWorkspace.managedResources.length})
              </span>
              <div className="mt-2 divide-y divide-slate-850 rounded-lg border border-slate-800 bg-slate-950 text-xs font-mono">
                {activeWorkspace.managedResources.map((res) => (
                  <div key={res.id} className="py-2 px-3 flex items-center justify-between">
                    <div>
                      <span className="text-indigo-400">{res.type}</span>
                      <span className="text-slate-400 ml-1.5">.{res.name}</span>
                    </div>
                    <span className="text-[11px] text-slate-500 truncate max-w-xs">{res.id}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
